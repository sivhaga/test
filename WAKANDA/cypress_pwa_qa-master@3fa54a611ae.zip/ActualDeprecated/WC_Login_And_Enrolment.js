const baseUrl = Cypress.env("baseUrl");
const device_sizes = Cypress.env("deviceSizes");
var current_view_port;

describe("To Test User Login", function () {

    beforeEach(function () {
        cy.visit(baseUrl)
        cy.wait(2000)
    })

    device_sizes.forEach((size) => {

        if (Cypress._.isArray(size)) {
            current_view_port = (size[0], size[1])
        }
        else {
            current_view_port = size
        }

        it('Valid User Login', function () {
            cy.viewport(current_view_port)

            cy.contains('button', 'LET’S GET STARTED').click()
            // cy.wait(2000)
            // cy.contains('button', 'Personal loans').click()
            // cy.get('ui-checkbox[name=income1]').click()
            // cy.get('ui-checkbox[name=income2]').click()
            // cy.get('ui-checkbox[name=income3]').click()
            // cy.contains('button', 'GET YOUR PRE APPROVED LOAN').click()
        })
    })
})