const device_sizes = ['iphone-6', 'ipad-2', 'macbook-13', 'iphone-6+', [1024, 800]]
const idNumber = '9710165175089'
const phoneNumber  = '0999999999'

//, 'ipad-2', 'macbook-13', 'iphone-6+', [1024, 800]

describe("Merchant Individual Login", function(){

    beforeEach(function(){
        // cy.visit('https://pwa-merchant-stage.wakago.net')
        try{
            cy.visit('https://pwa-merchant-test.wakago.net/enrollment')
        }
        catch(error){
            console.log(error);
        }
        
    })

    device_sizes.forEach((size)=>{

        it('Search for a service for device', function() {                                                                                                                                                                                        
            if(Cypress._.isArray(size)){                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                cy.viewport(size[0], size[1])
            }
            else{
                cy.viewport(size)
            }

            // cy.pause()
            cy.contains('button', 'LET’S GET STARTED').click()
            cy.contains('button', 'Onboarding').click()
            cy.contains('INDIVIDUAL').click({force:true})
            cy.contains('INDIVIDUAL')
            cy.contains('CONTINUE').click()
            cy.get('input[name=id]').type(idNumber).should('have', idNumber)
            cy.get('input[name=cellphone]').type(phoneNumber).should('have', phoneNumber)
            cy.get('body > wakanda-root > app-main-layout-without-header-navigation > main > div > wakanda-customer-onboarding-start > ui-container > div > ui-segment > div > div > ui-checkbox:nth-child(1) > div > div > span').click()
            cy.get('body > wakanda-root > app-main-layout-without-header-navigation > main > div > wakanda-customer-onboarding-start > ui-container > div > ui-segment > div > div > ui-checkbox:nth-child(2) > div > div > span').click()
            cy.get('body > wakanda-root > app-main-layout-without-header-navigation > main > div > wakanda-customer-onboarding-start > ui-container > div > ui-segment > div > div > ui-checkbox:nth-child(3) > div > div > span').click()
            cy.contains('GENERATE OTP').click()
        })
    })
})