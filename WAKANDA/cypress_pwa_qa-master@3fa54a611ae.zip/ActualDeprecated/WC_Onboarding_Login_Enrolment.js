const device_sizes = ['iphone-6']
var current_view_port = ''
const idNumber = '9710165175089'
const phoneNumber  = '0999999999'
const Username = 'test1'
const password = 'Heslo123'

//, 'ipad-2', 'macbook-13', 'iphone-6+', [1024, 800]

describe("Onboading, Login and Enrolment", function(){

    beforeEach(function(){
        cy.visit('https://pwa-stage.wakago.net')
        cy.wait(2000)
    })

    device_sizes.forEach((size)=>{

        if (Cypress._.isArray(size)) {
            current_view_port = (size[0], size[1])
        }
        else {
            current_view_port = size
        }

        it('Onboards a User', function() {   
            cy.viewport(current_view_port)       

            cy.contains('button', 'LET’S GET STARTED').click()
            cy.contains('button', 'SIGN UP').click()
            cy.get('input[name=id]').type(idNumber).should('have', idNumber)
            cy.get('input[name=cellphone]').type(phoneNumber).should('have', phoneNumber)
            cy.get('body > wakanda-root > app-main-layout-without-header-navigation > main > div > wakanda-customer-onboarding-start > ui-container > div > ui-segment > div > div > ui-checkbox:nth-child(1) > div > div > span').click()
            cy.get('body > wakanda-root > app-main-layout-without-header-navigation > main > div > wakanda-customer-onboarding-start > ui-container > div > ui-segment > div > div > ui-checkbox:nth-child(2) > div > div > span').click()
            cy.get('body > wakanda-root > app-main-layout-without-header-navigation > main > div > wakanda-customer-onboarding-start > ui-container > div > ui-segment > div > div > ui-checkbox:nth-child(3) > div > div > span').click()
            cy.contains('button','GENERATE OTP').click()
            cy.contains('button','GENERATE OTP').should('not.be.visible')
        })

        it('Log User In', function(){
            cy.viewport(current_view_port)       

            cy.contains('button', 'LET’S GET STARTED').click()
            cy.contains('button', 'LOG IN').click()
            cy.get('input[name=username]').type(Username).should('have', Username)
            cy.contains('button', 'Login').click()
            cy.get('input[name=password]').type(password).should('have', password)
            cy.contains('button', 'Login').click()
            cy.get('.ui.pin-wrapper')
            .find('span.pin-item')
            .find('input')
            .eq(0)
            .click()
            .type(1)


        cy.get('.ui.pin-wrapper')
            .find('span.pin-item')
            .find('input')
            .eq(1)
            .click()
            .type(2)

        cy.get('.ui.pin-wrapper')
            .find('span.pin-item')
            .find('input')
            .eq(2)
            .click()
            .type(3)


        cy.get('.ui.pin-wrapper')
            .find('span.pin-item')
            .find('input')
            .eq(3)
            .click()
            .type(4)

            cy.get('.ui.pin-wrapper')
            .find('span.pin-item')
            .find('input')
            .eq(4)
            .click()
            .type(5)

        cy.contains('button', 'VERIFY').click()

        cy.get('.ui.select').find('input').should('not.be.visible')

        })
    })
})