//import "./login.spec";
import "./commands";
describe("Wallet", function () {

    beforeEach(function () {
        cy.customerloign();
        cy.restoreLocalStorageCache();
        cy.wait(15000);
        cy.contains('Wallet').click({ force: true });
        cy.wait(12000);
//        cy.get('.header-title').should('have.text', 'AVO Wallet');
    });


    it('Top up my Wallet with an existing card', function(){
        cy.wait(5000);
        cy.contains('Top up').click();
        cy.wait(10000);
        cy.contains('INSTANT METHODS').click();
        cy.contains('Wallet').click({ force: true }); //Go back
    });

    it('Wallet Generate QR code with Amount', function() {
        cy.wait(5000);
        cy.contains('Request').click();
        cy.contains(Cypress.env('customerFullName'));
        cy.wait(9000);
        cy.get('input').type(20);
        cy.wait(2000);
        cy.contains('button', 'GENERATE QR CODE').should('be.visible').click();
        cy.wait(2000);
        cy.contains('20');
        cy.contains('Pay');
        cy.contains('button', 'CLOSE').click();
    });

    it('Wallet Request Payment', function() {
        cy.wait(5000);
        cy.contains('Request').click();
        cy.wait(10000);
        cy.contains('REQUEST MONEY').click();
        cy.wait(15000);
        cy.get('input[name=phoneNumber]').type(Cypress.env('requestPaymentPhoneNumber'));
        cy.contains('button', 'Continue').click();
        cy.wait(1000);
        cy.get('input[name=amount]').type('80');
        cy.get('input[name=description]').type('TestDescription_20');
        cy.get('input[name=reference]').type('TestRef_20');
        cy.wait(1000);
        cy.get('#btn-553').click();
        cy.wait(5000);
        cy.completeOTP();
        cy.wait(2000);
        cy.get('#btn-981').click({ force: true });
        cy.wait(5000);
        //cy.contains("Payment request sent"); //nolonger visible
        //cy.contains('button', 'See details').click(); //nolonger visible
    });

    it('Pay to cellphone number', function() {
        cy.wait(5000);
        cy.contains('Pay').click();
        cy.wait(5000);
        cy.get('#txtf-1155').type(Cypress.env('requestPaymentPhoneNumber'));
        cy.get('#btn-613').should('be.visible').click();

        //payment amount
        cy.get('#txtf-660').type('20');
        cy.get('#txtf-1188').type('Testiong123');
        cy.get('#btn-510').should('be.visible').click();
        cy.completeOTP();
        cy.get('#btn-981').should('be.visible').click();
        cy.wait(15000);
        cy.contains("success").should('be.visible'); //broken payment

    });

});