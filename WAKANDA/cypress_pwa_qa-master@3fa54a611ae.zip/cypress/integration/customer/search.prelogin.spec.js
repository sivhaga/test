//import "./private.login.spec";
var searchChar = 'tab';
describe("/dashboard", function () {

    before(function () {
        cy.visit("/");
        cy.wait(4000);
        cy.get('#txtf-520').type('test@nedbank.co.za');
        cy.get('#btn-468').should('be.enabled').click({force: true});
//        cy.get('#btn-1590').should('be.enabled').click({force: true}); //Let\'s get started'
        cy.wait(2000);
    });


    it('Clicks the search field and validates the text Trending', function () {
        cy.get("input").click();
        cy.contains("Trending");
        cy.wait(2000);
        cy.get('.light').its('length').should('be.gte', 0);
    });

    it('Enters a value to search and validates that the text is displayed on the result list', function (){
        cy.get("input").type(searchChar);
        cy.wait(2000);
        
        var resultItems = cy.get('.select-item');
        resultItems.find('p').contains(searchChar);
        resultItems.its('length').should('be.gte', 0);

        cy.get('.select-item').find('p').first().click();
        cy.wait(10000);
        cy.contains('results in all Product');

        cy.get('.description').its('length').should('be.gte', 0);
    });
});