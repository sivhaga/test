import "../customer/commands";
//import "./merchant.private.login.spec";

const avoOneCartInfos = ["Name and surmane", "Cellphone Number", "Saved addresses", "Email address"]
const airtimeAmt = 5;
const reference = 'TESTING123';
const meterNumber = '01050020001';
const electrAmt = 20;
const requestPaymentPhoneNumber = 780124835;
describe("Buy prepaid services", function () {

    beforeEach(function () {
            cy.restoreLocalStorageCache();
            cy.merchantloign();

        });

        afterEach(function() {
                cy.saveLocalStorageCache();
                cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
                cy.wait(5000);
                cy.contains('LOGOUT').scrollIntoView()
                cy.contains('LOGOUT').should('be.visible').click({force: true});
            });

        it('Buys Prepaid Airtime', function () {
//                cy.wait(2000)
//                cy.get('#elem-824').click({force: true})
//                cy.wait(3000)

                cy.contains('Airtime & Data').click({ force: true });
                cy.wait(5000)

                cy.contains('Who would you like to buy airtime or data for?');

                cy.get('#txtf-538').type(requestPaymentPhoneNumber);

                cy.get('#btn-1496').should('be.visible').click();

                cy.contains('Choose a provider');
                cy.contains('Vodacom').click({ force: true });
                cy.contains('Airtime').click({ force: true });
                cy.contains(' Own amount ').click({ force: true });
                cy.get('#txtf-1295').type(airtimeAmt);

                cy.get('#btn-549').should('be.visible').click()
                cy.wait(1000);

                cy.get('#txtf-1188').type(reference);
                cy.get('#btn-718').should('be.enabled').click();
                cy.wait(22000);
                cy.contains('Payment Successful!'); //will changeit when fixed

            })

             it('Buys Data Bundles', function () {
//                        cy.wait(2000)
//                        cy.visit('/dashboard/v1/customer/board');
//                        cy.wait(5000)
//                        cy.get('#elem-824').click({force: true})
//                        cy.wait(3000)

                        cy.contains('Airtime & Data').click({ force: true });
                        cy.wait(5000)

                        cy.contains('Who would you like to buy airtime or data for?');

                        cy.get('#txtf-538').type(requestPaymentPhoneNumber);

                        cy.get('#btn-1496').should('be.visible').click();

                        cy.contains('Choose a provider');
                        cy.contains('Vodacom').click({ force: true });
                        cy.contains('Data').click({ force: true });
                        cy.contains(' Bundle ').click({ force: true });
                        cy.contains('See all bundles').click({ force: true });
                        cy.xpath('//*[@id="scrollingContent"]/div/ul/li[1]/p').click({ force: true });

                        //cy.cont  ains('button', ' BUY R' + airtimeAmt + '.00 ').click()
                        cy.get('button').should('be.enabled').click();
                        cy.wait(1000);

                        cy.get('input[name=description]').type(reference);
                        cy.get('button').should('be.enabled').click();
                        cy.wait(22000);
                        cy.contains('Payment Successful!'); //will changeit when fixed

                    })


                    it('Buys Prepaid Electricity', function () {

//                                          cy.visit('/dashboard/v1/customer/board');
//                                          cy.wait(5000)
//                                          cy.get('#elem-824').click({force: true})
//                                          cy.wait(3000)

                              cy.contains('Electricity').click({ force: true });
                              cy.wait(5000)

                              cy.get('#txtf-1469').type(requestPaymentPhoneNumber);
                              cy.get('#txtf-1158').type(meterNumber);
                              cy.get('#txtf-660').type(electrAmt);
                              cy.wait(20000);

                              cy.get('#btn-446').should('be.enabled').click();

                              cy.contains('Total Payable Amount');
                              cy.contains('R' + electrAmt + '.00');

                              cy.get('button').should('be.enabled').click();
                              cy.wait(15000);

                              cy.contains('Payment Successful!');
                              cy.screenshot('Electricity purchase success');
                              cy.contains('Reference number');
                              cy.contains(' CLOSE ').click();

                     })

    })