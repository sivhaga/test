import "../customer/commands";
//import "./merchant.login.spec";

describe("MY ACCOUNT", function () {

    beforeEach(function () {
        cy.restoreLocalStorageCache();
        cy.merchantloign();
    });


     after(function() {
        cy.saveLocalStorageCache();
        cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
        cy.wait(5000);
        cy.contains('LOGOUT').scrollIntoView()
        cy.contains('LOGOUT').should('be.visible').click({force: true});
    });

    it('Navigates to and validate MY ACCOUNT page', function () {

            cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
            cy.wait(5000);
            //check filter dates
            cy.contains('TIMES HIRED').should('be.visible');
            cy.contains('USER RATING').should('be.visible');
            cy.contains('REVIEWS').should('be.visible');
            cy.contains('Past Projects').should('be.visible');
            cy.contains('Saved Accounts & Cards').should('be.visible');
            cy.contains('Job Settings').scrollIntoView();
            cy.contains('Job Settings').should('be.visible');
            cy.contains('App Settings').scrollIntoView();
            cy.contains('App Settings').should('be.visible');
            cy.contains('Wallet Info').scrollIntoView().scrollIntoView();
            cy.contains('Wallet Info').should('be.visible');
            cy.contains('Help').should('be.visible');
            cy.contains('ATM & Branches').should('be.visible');
            cy.contains('Legal').should('be.visible');
            cy.contains('Contact us').should('be.visible').scrollIntoView();
            cy.contains('LOGOUT').should('be.visible');


        });

//        it('Navigates to Past Projects', function () {
//
//            cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
//            cy.wait(8000);
//
//            cy.contains('Past Projects').should('be.visible').click({force: true});
//            cy.wait(15000);
//            cy.get('.inner').should('be.visible').click({force: true});
//            cy.wait(8000);
//            cy.contains('Project status').should('be.visible');
//            cy.contains('Job ID').should('be.visible');
//
//            //buttons
//            cy.get('#btn-1202').should('be.visible');
//            cy.get('#btn-1180').should('be.visible');
//            cy.get('#btn-933').should('be.visible');
//         })  //Broken BUGGGGG

          it('Navigates to Saved Accounts & Cards', function () {

             cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
             cy.wait(5000);

             cy.contains('Saved Accounts & Cards').should('be.visible').click({force: true});
             cy.wait(1000);
             cy.contains('Add funding').should('be.visible'); //adding bank account is broken
             cy.contains(' Funding ').should('be.visible');
             cy.contains(' Withdrawal ').should('be.visible'); //Withdrawal page is broken

             //go to withdrawal
             cy.get('#btn-1047').should('be.visible').click({force: true});

          })

          it('Navigates to Job Settings', function () {

           cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
           cy.wait(5000);
           cy.contains('Job Settings').scrollIntoView();
           cy.contains('Job Settings').should('be.visible').click({force: true});
           //settings page
           cy.contains('Current Location set to').should('be.visible');
           cy.contains('LOCATION SETTINGS').should('be.visible');
           cy.contains('LOCATION SETTINGS').should('be.visible');

          //toogle Restrict Jobs by distance      NB:ToBeScripted
//          cy.get('.toggle-control')
//            .invoke('val', 25)
//            .trigger('change', {force: true}).last()
//            .get('#range-1')
//            .should('have.text', '25')
//
         })

         it('Navigates to App Settings', function () {

            cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
            cy.wait(7000);
            cy.contains('App Settings').scrollIntoView()
            cy.contains('App Settings').should('be.visible').click({force: true});
            //go to notifications settings
            cy.contains('Notifications').should('be.visible').click({force: true});
            //toogle buttons on
            cy.contains('General').should('be.visible').click({force: true});
            cy.wait(3000);
            cy.contains('Promotions').should('be.visible').click({force: true});
            cy.wait(3000);
            cy.contains('Orders').should('be.visible').click({force: true});
            //toogle buttons off
            cy.contains('General').should('be.visible').click({force: true});
            cy.get('#btn-1085').click({force: true});
            cy.wait(3000);
            cy.contains('Promotions').should('be.visible').click({force: true});
            cy.get('#btn-1085').click({force: true});
            cy.wait(3000);
            cy.contains('Orders').should('be.visible').click({force: true});
            cy.wait(2000);
            cy.get('#btn-1085').click({force: true});
            cy.wait(3000);

            //go back to setting
            cy.xpath('/html/body/wakanda-merchant-root/app-main-layout-with-navigation/main/wakanda-merchant-header/header/span[1]/ui-svg').click({force: true});
            //go to change password
            cy.contains('Change Password').should('be.visible').click({force: true});
            cy.get('#txtf-883').type(Cypress.env('merchantPassword'));
            cy.get('#txtf-1601').type(Cypress.env('merchantPassword'));
            //chnge button
            cy.get('#btn-1676').click({force: true});   //System broken from this point
            cy.wait(10000);
            cy.completeOTP();
            cy.get('#btn-981').click();
            cy.wait(5000);
         })

         it('Navigates to Wallet Info and validate', function () {

            cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
            cy.wait(5000);

            cy.contains('Wallet Info').scrollIntoView()
            cy.contains('Wallet Info').should('be.visible').click({force: true});
            cy.wait(5000);
            //validate the contents
            cy.contains('WALLET INFO').should('be.visible');
            cy.contains('Wallet account number').should('be.visible');
             cy.wait(2000);
            cy.contains('Wallet Limits').should('be.visible');
            cy.contains('Daily outgoing').should('be.visible');
            cy.contains('Wallet Balance').should('be.visible');
            cy.contains('Single ATM Withdrawal').should('be.visible');
            cy.contains('Purchase of Prepaids').should('be.visible');
            cy.contains('Settle to Bank').should('be.visible');

          })

          it('Navigates to Help page and validate', function () {

            cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
            cy.wait(5000);

            cy.contains('Help').scrollIntoView()
            cy.contains('Help').should('be.visible').click({force: true});
            cy.wait(10000);
            //validate the contents
            cy.get('#main-chat-input').type('Help Testing 123');
            cy.get('#send-message').click({force: true});
            cy.wait(10000);
            cy.contains('Help Testing 123').should('be.visible');

          })

          it('Navigates to ATM & Branches page and validate', function () {

            cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
            cy.wait(5000);

            cy.contains('ATM & Branches').scrollIntoView()
            cy.contains('ATM & Branches').should('be.visible').click({force: true});
            cy.wait(5000);
            //validate the contents

          })

          it('Navigates to Legal page and validate', function () {

            cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
            cy.wait(5000);

            cy.contains('Legal').scrollIntoView()
            cy.contains('Legal').should('be.visible').click({force: true});
            cy.wait(5000);
            //go to T&Cs page and back
            cy.contains('T&Cs').should('be.visible').click({force: true});
            cy.xpath('/html/body/wakanda-merchant-root/app-main-layout-with-navigation/main/wakanda-merchant-header/header/span[1]/ui-svg').click({force: true});
            cy.wait(5000);
            //go to T&Cs page and back
            cy.contains('Privacy Policy').should('be.visible').click({force: true});
            cy.xpath('/html/body/wakanda-merchant-root/app-main-layout-with-navigation/main/wakanda-merchant-header/header/span[1]/ui-svg').click({force: true});


          })

          it('Navigates to Contact us page and validate', function () {

            cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
            cy.wait(5000);

            cy.contains('Contact us').scrollIntoView()
            cy.contains('Contact us').should('be.visible').click({force: true});
            cy.wait(5000);
            //validate the contents
            cy.contains('https://avo.africa').should('be.visible');
            cy.contains('hello@avo.africa').should('be.visible');
            cy.contains('0860 100 833').should('be.visible');
            cy.contains('HOME').click({force: true});
            cy.wait(2000);
          })
})