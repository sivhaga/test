describe("/dashboard", function () {

    before(function () {
        cy.fixture('dashboard').then(function (data) {
            this.data = data
        })
    })

    beforeEach(function () {
        cy.visit('https://www.soko.life/home')
        cy.contains('button', 'LET’S GET STARTED').click()
    })

    it('categories', function () {
        cy.get('.home.filter-buttons')
            .find('ui-button')
            .should('have.length', 6)
    })

    it('get great experience', function () {
        cy.get('.sign-up.wrapper')
            .find('h3').eq(0)
            .should('have.text', "Get the best experience!")
    })

    it('protect your payment', function () {
        cy.get('.widget').eq(0).should('have.length', 1)
        cy.get('.ui-item.dark-grad.mid-green.round-corners.has-close.compact.full-width')
            .find('.item-wrapper')
            .find('.inner')
            .find('.description')
            .find('h4')
            .contains("PROTECT YOUR PAYMENTS ON SOKO")
    })

    it('with payment protection', function () {
        cy.get('.ui-item.dark-grad.mid-green.round-corners.has-close.compact.full-width')
            .find('.item-wrapper')
            .find('.inner').find('.description')
            .find('p')
            .contains("With payment protection, use your money to pay only when you receive a product, or finish a service ")
    })

    it('grab your deal', function () {
        cy.get('.title-block')
            .eq(0)
            .find('h3')
            .contains("GRAB YOUR DEAL ")
    })

    it('shop for your home', function () {
        cy.get('.title-block')
            .eq(1).find('h3')
            .contains("Shop for your home")
    })

    it('finance everything, with nedbank', function () {
        cy.get('.title-block')
            .eq(2).find('h3')
            .contains("Finance everything, with nedbank")
    })

    it('get an instant loan ', function () {
        cy.get('.ui-item.has-shadow.round-corners.compact')
            .find('.item-wrapper')
            .find('.inner')
            .find('.description')
            .find('h4')
            .contains("Get an instant loan for all your purchases")
    })

    it('check your eligibility now', function () {
        cy.get('.ui-item.has-shadow.round-corners.compact')
            .find('.item-wrapper')
            .find('.inner')
            .find('.description')
            .find('p')
            .contains("Check your eligibility now!")
    })

    it('scroll down dashboard page', function () {
        cy.scrollTo(0, 600)
    })
})