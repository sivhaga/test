//import "./private.login.spec";
import "./commands";
var current_view_port;
var baseUrl = Cypress.env("customerLoginUrl");
var device_sizes = Cypress.env("deviceSizes");

describe("Avo User login and Recovery", function () {
     beforeEach(function () {
        //cy.customerloign();
        cy.restoreLocalStorageCache();

    });

    afterEach(function() {
        cy.saveLocalStorageCache();
    });

    it('Recover Username', function () {
     cy.visit("/");
        cy.wait(2000);
        cy.get('#txtf-520').type('test@nedbank.co.za');
        cy.get('#btn-468').should('be.enabled').click({force: true});
        //cy.get('#btn-1590').should('be.enabled').click({force: true}); //Let\'s get started
        cy.wait(2000);
        cy.get('#btn-409').click({force: true}); //Button login
        cy.contains('Forgot username?').click();
        cy.wait(3000);
        cy.get('input[name=saIdNumber]').type(Cypress.env('customerSaIdNumber'), {force: true});
        cy.wait(1000);
        cy.get('input[name=phoneNumber]').type(Cypress.env('customerPhoneNumber'));
        cy.wait(1000);
        cy.contains('button', 'RECOVER USERNAME').click();
        cy.wait(3000);
        cy.contains('We\'ve sent you an SMS with your username.');
        cy.contains('Resend SMS');
        cy.contains('button', 'LOGIN').click();
        cy.wait(2000);
    });

    it('Recover Password', function () {
        cy.get('input[name=username]').type(Cypress.env('customerRecoveryUsername'));
        cy.wait(1000);
        cy.get('#btn-377').should('be.enabled').click();
        cy.contains('Forgot password?').click();
        cy.wait(2000);
        cy.get('input[name=username]').type(Cypress.env('customerRecoveryUsername'));
        cy.get('#btn-613').should('be.enabled').click();
        cy.completeOTP();
        cy.wait(1000);
        cy.contains('button', 'VERIFY').click();
        cy.wait(2000);
        cy.get('input[name=password]').type(Cypress.env('customerRecoveryPassword'));
        cy.get('input[name=confirmPassword]').type(Cypress.env('customerRecoveryPassword'));
        cy.wait(1000);
        cy.contains('button', 'CONTINUE').should('be.enabled').click({force: true});
        cy.wait(5000);
    });

    it('Login to Confirm Password Recovery', function () {
        cy.get('input[name=username]').type(Cypress.env('customerRecoveryUsername'));
        cy.wait(1000);
        cy.get('#btn-377').should('be.enabled').click();
        cy.get('input[name=password]').type(Cypress.env('customerRecoveryPassword'));
        cy.wait(1000);
        cy.contains('button', 'LOGIN').should('be.enabled').click();
        cy.wait(2000);
        cy.contains("OTP");
    });

    it('Revert to Old Password', function () {
        cy.visit('/');
        cy.contains('button', 'LOG IN').click();
        cy.get('input[name=username]').type(Cypress.env('customerRecoveryUsername'));
        cy.wait(1000);
        cy.get('#btn-377').should('be.enabled').click();
        cy.contains('Forgot password?').click();
        cy.wait(2000);
        cy.get('input[name=username]').type(Cypress.env('customerRecoveryUsername'));
        cy.get('#btn-613').should('be.enabled').click();
        cy.completeOTP();
        cy.wait(1000);
        cy.contains('button', 'VERIFY').click();
        cy.wait(2000);
        cy.get('input[name=password]').type(Cypress.env('customerOriginalPassword'));
        cy.get('input[name=confirmPassword]').type(Cypress.env('customerOriginalPassword'));
        cy.wait(1000);
        cy.contains('button', 'CONTINUE').should('be.enabled').click({ force: true });
        cy.wait(3000);
    });
});
