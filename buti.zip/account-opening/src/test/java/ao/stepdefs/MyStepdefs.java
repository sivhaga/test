package ao.stepdefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;

import io.restassured.RestAssured;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.json.JSONException;



import java.util.HashMap;
import static io.restassured.config.RedirectConfig.redirectConfig;


public class MyStepdefs {

    private  String code;
    private String access_token;



    @Given("^I want to send a request$")
    public void i_want_to_send_a_request() throws  JSONException{
        //  Write code here that turns the phrase above into concrete actions
        Response response, respone2;
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("code_challenge_method","S256");
        map.put("","");
        map.put("","");
        map.put("prompt","login");

        //request builder  - use this one
//RequestSpecification spec = new RequestSpecBuilder().setConfig(RestAssured.config().redirect(redirectConfig().followRedirects(false))).build();
        //for all requests
        //all requests:
        //RestAssured.config = config().redirect(redirectConfig().followRedirects(true).and().maxRedirects(0));

        response = RestAssured.given().relaxedHTTPSValidation().when().config(RestAssured.config().redirect(redirectConfig().followRedirects(false)))
                .params(map).get("");
        code = response.header("Location").substring(28);

        HashMap<String, String> map1 = new HashMap<String, String>();
        map1.put("code",code);
        map1.put("redirect_uri","");
        map1.put("","");
        map1.put("","");
        map1.put("","");

        System.out.println(code);

        response.then().log().all();

        respone2 = RestAssured.given().relaxedHTTPSValidation().when().config(RestAssured.config().redirect(redirectConfig().followRedirects(false))).header("Content-Type","application/x-www-form-urlencoded")
                .params(map1).post("");

        System.out.println("----------------------------");

        respone2.then().log().all();

        JSONObject jsonObj = new JSONObject(respone2.asString());
        access_token  = jsonObj.getString("access_token");


        System.out.println(access_token);

        //---------

        System.out.println("----------------------------");

        HashMap<String, String> header= new HashMap<String, String>();
        header.put("","");
        header.put("","");
        header.put("accept","application/json");
        header.put("authorization",access_token);
        header.put("","");
        header.put("x-sbg-zone","active");

        Response response3 = RestAssured.given().relaxedHTTPSValidation().headers(header).when().get("https://sit-gateway.apinp.standardbank.co.za/sit/sit/sbg-ao/accounts/savings-and-investments/eligibility");
        response3.then().log().all();
        response3.then().statusCode(200);



    }


    @And("validate the response")
    public void validateTheResponse() {
    }


}
