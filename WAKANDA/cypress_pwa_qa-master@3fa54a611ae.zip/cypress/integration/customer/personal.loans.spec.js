import "./login.spec";
import "./commands";
describe("Personal Loans", function () {

    beforeEach(function () {
        cy.restoreLocalStorageCache();
    });

//     after(function() {
//             cy.visit("/");
//             cy.wait(5000);
//             cy.contains('More').click({force: true});
//             cy.get('#btn-634').scrollIntoView(); //LOGOUT
//             cy.get('#btn-634').click({force: true}); //LOGOUT
//             cy.wait(5000);
//        });

    /*it('Starts the Instant Loans Process', function () {
        cy.wait(5000);
        cy.get('.ui-personal-loans-widget').click();
        cy.wait(2000);
        cy.get('.ui-checkbox').each(function($checkBoxes) {
            $checkBoxes.find('img').click();
        });
        cy.get('button').click();
        cy.wait(20000);
    });

    it('Does NedId Login', function() {
        cy.get('iframe').then(function ($iframe){
            var body = $iframe.first().find('body');

            cy.wrap(body).contains('button').should('not.be.visible');
            cy.wrap(body).find('input[name=username]').type(Cypress.env('PL_UserDetails.username'));
            cy.wrap(body).find('input[name=password]').type(Cypress.env('PL_UserDetails.password'));
            cy.wrap(body).contains('#login').click();
        });
    }); */
});