//import "./login.spec"
import "./commands"
describe("Entertainment", function () {

     beforeEach(function () {
        cy.customerloign();
        cy.restoreLocalStorageCache();

    });

    afterEach(function() {
        cy.saveLocalStorageCache();
    });


    it('Navigate to Entertainment screen and Redirect to NuMetro and book a movie', function () {
        cy.wait(5000);
        cy.contains('Categories').should('be.visible').click({force: true});
        cy.wait(3000);
        //cy.contains('Entertainment').click({force: true}); Label name changed
        cy.contains('Entertain').scrollIntoView()
        cy.xpath('//*[@id="scrollingContent"]/div/div[8]/div/div/h3').click({force: true});
        cy.contains('Movies').should('be.visible');
        cy.wait(2000);


        //'Selects movies category',
        cy.contains('Movies').should('be.visible').click({force: true});
        cy.wait(3000);


       //'Choose a movie'
       cy.xpath('/html/body/wakanda-root/app-main-layout/main/ng-component/ui-container/div/div/div/div[3]/wakanda-customer-movie-item[1]/div/div[1]/div/img').click();
       cy.wait(2000);


        //'Validates the product details page contents
        cy.contains('To give you the best experience, we need to share some of your info.').should('be.visible');
        //cy.contains('Earn AVO points on your purchase!').should('be.visible');
        cy.contains('See Privacy Policy.').should('be.visible');
        cy.contains(' LET\'S GO ').should('be.visible');
        cy.wait(2000);

        cy.get('#btn-533').click();
        cy.wait(5000);

        cy.get('iframe')
          .then(function ($iframe) {
            const $jbody = $iframe.contents().find('body')
            const $body = $jbody[0]
            cy.wrap($body).xpath('//*[@id="screen1"]/div[2]/div/div[1]/p/span').click();
            cy.wrap($body).xpath('//*[@id="output"]/tr[1]/td[1]').should('be.visible').click();
            cy.wait(2000);
            cy.wrap($body).xpath('//*[@id="experience_container"]/div/div[2]/div/div[4]/a').should('be.visible').click();
            cy.wait(5000);
          })

           cy.get('iframe')
               .then(function ($iframe) {
               const $jbody = $iframe.contents().find('body');
               const $body = $jbody[0];
               cy.wait(1000);
               cy.wrap($body).contains('SCREEN').should('be.visible');

               var seatcolm =  ["A", "B", "C","D", "E","F","G","H","J","K"];
               var seatrow = Math.floor(Math.random() * 10)+1;

               //if(cy.wrap($body).contains(seatcolm[seatrow]+seatrow)){

               try{
                    cy.wrap($body).contains(seatcolm[seatrow]+seatrow).click();
               }catch {
                  alert('//please retry 1")');
                  try{
                    seatrow = Math.floor(Math.random() * 10)+1;
                    cy.wrap($body).contains(seatcolm[seatrow]+seatrow).click();
                  }catch{
                      //please retry 2")
                      try{
                          seatrow = Math.floor(Math.random() * 10)+1;
                          cy.wrap($body).contains(seatcolm[seatrow]+seatrow).click();
                      }catch(err) {}
                  }
                }

               //}


                cy.wait(3000);


              })

              cy.get('iframe')
                 .then(function ($iframe) {
                 const $jbody = $iframe.contents().find('body');
                 const $body = $jbody[0];
                 cy.wait(1000);
                 cy.wait(3000);
                 cy.wrap($body).contains('Check Out').scrollIntoView()
                 cy.wrap($body).contains('Check Out').should('be.enabled').click({force: true});
                 cy.wait(3000);
              })
                        //comment screen channged , needs card details

//              cy.get('#btn-663').click();
//              cy.wait(10000);
//              cy.completeOTP();
//              cy.contains('button', ' Confirm PIN ').click();
//              cy.wait(10000);
//              cy.contains('Your tickets are successfully booked and paid.').should('be.visible');
//              cy.contains('ORDER NO:').should('be.visible');
//              cy.contains('You\'ve earned ').should('be.visible');
//              cy.get('button[id=btn-514]').click();
//              cy.wait(3000);

          })



                it('Apply discount to each seat individually.', function () {
                                cy.wait(8000);
                                cy.contains('Categories').should('be.visible').click({force: true});
                                cy.wait(3000);
                                //cy.contains('Entertainment').click({force: true}); Label name changed
                                cy.contains('Entertain').scrollIntoView()
                                cy.xpath('//*[@id="scrollingContent"]/div/div[8]/div/div/h3').click({force: true});
                                cy.contains('Movies').should('be.visible');
                                cy.wait(2000);
                                cy.contains('Movies').should('be.visible').click({force: true});
                                cy.wait(3000);
                                cy.xpath('/html/body/wakanda-root/app-main-layout/main/ng-component/ui-container/div/div/div/div[3]/wakanda-customer-movie-item[1]/div/div[1]/div/img').click(); //choose movie
                                cy.wait(2000);
                                cy.contains('To give you the best experience, we need to share some of your info.').should('be.visible');
                                //cy.contains('Earn AVO points on your purchase!').should('be.visible');
                                cy.contains('See Privacy Policy.').should('be.visible');
                                cy.contains(' LET\'S GO ').should('be.visible');
                                cy.wait(2000);

                                cy.get('#btn-533').click();
                                cy.wait(5000);

                                cy.get('iframe')
                                  .then(function ($iframe) {
                                    const $jbody = $iframe.contents().find('body')
                                    const $body = $jbody[0]
                                    cy.wrap($body).xpath('//*[@id="screen1"]/div[2]/div/div[1]/p/span').click();
                                    cy.wrap($body).xpath('//*[@id="output"]/tr[1]/td[1]').should('be.visible').click();
                                    cy.wait(2000);
                                    cy.wrap($body).xpath('//*[@id="experience_container"]/div/div[2]/div/div[3]/a').should('be.visible').click();
                                    cy.wait(5000);
                                  })

                                   cy.get('iframe')
                                       .then(function ($iframe) {
                                       const $jbody = $iframe.contents().find('body');
                                       const $body = $jbody[0];
                                       cy.wait(1000);
                                       cy.wrap($body).contains('SCREEN').should('be.visible');

                                       var seatcolm =  ["A", "B", "C","D", "E","F","G","H","J","K"];
                                       var seatrow = Math.floor(Math.random() * 10)+1;

                                       if(cy.wrap($body).contains(seatcolm[seatrow]+seatrow)){
                                       try{
                                            cy.wrap($body).contains(seatcolm[seatrow]+seatrow).click();
                                       }catch(err) {
                                          //please retry 1")
                                          try{
                                            seatrow = Math.floor(Math.random() * 10)+1;
                                            cy.wrap($body).contains(seatcolm[seatrow]+seatrow).click();
                                          }catch(err) {
                                              //please retry 2")
                                              try{
                                                  seatrow = Math.floor(Math.random() * 10)+1;
                                                  cy.wrap($body).contains(seatcolm[seatrow]+seatrow).click();
                                              }catch(err) {}
                                          }
                                        }

                                       }


                                        cy.wait(5000);
//                                        cy.wrap($body).contains('Momentum Multiply').scrollIntoView()
//                                        cy.wrap($body).contains('Momentum Multiply').should('be.enabled');
//                                        cy.wrap($body).contains('Sanlam Reality').should('be.enabled');
//                                        cy.wrap($body).contains('Nu Metro Digiticket').should('be.enabled');
                                        cy.wait(3000);


                                      })
                                      cy.get('iframe')
                                           .then(function ($iframe) {
                                           const $jbody = $iframe.contents().find('body');
                                           const $body = $jbody[0];
                                           cy.wait(1000);
                                           cy.wait(3000);
                                           cy.wrap($body).contains('Check Out').scrollIntoView()
                                           cy.wrap($body).contains('Check Out').should('be.enabled').click({force: true});
                                           cy.wait(10000);
                                      } );
                                      //comment screen channged , needs card details

//                                      cy.get('#btn-663').click();
//                                      cy.wait(10000);
//                                      cy.completeOTP();
//                                      cy.contains('button', ' Confirm PIN ').click();
//                                      cy.wait(10000);
//                                      cy.contains('Your tickets are successfully booked and paid.').should('be.visible');
//                                      cy.contains('ORDER NO:').should('be.visible');
//                                      cy.contains('You\'ve earned ').should('be.visible');
//                                      cy.get('button[id=btn-514]').click();
//                                      cy.wait(3000);

                                })

})