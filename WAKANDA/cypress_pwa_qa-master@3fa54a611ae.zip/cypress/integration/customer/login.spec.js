import "./commands";
var current_view_port;
var baseUrl = Cypress.env("customerLoginUrl");
var device_sizes = Cypress.env("deviceSizes");

describe("Avo User login", function () {

    beforeEach(function () {
    cy.restoreLocalStorageCache();
        cy.visit("/");
        cy.wait(2000);
    });

    afterEach(function () {
        cy.saveLocalStorageCache();
    });

    it('Enrolls and Logs in the User', function () {
//        cy.get('#txtf-520').type('test@nedbank.co.za');
//        cy.get('#btn-468').should('be.enabled').click({force: true});
//        cy.get('#btn-1590').should('be.enabled').click({force: true}); //Let\'s get started'
//        cy.get('#btn-409').should('be.enabled').click({force: true}); //LOgin
        cy.wait(1000);
        cy.get('#txtf-520').type('test@nedbank.co.za');
       cy.get('#btn-468').should('be.enabled').click({force: true});
        cy.get('#btn-409').should('be.enabled').click({force: true}); //LOgin
        cy.get('#txtf-864').type(Cypress.env('customerUsername'));
        cy.wait(1000);
        cy.get('#btn-377').should('be.enabled').click(); //button
        cy.wait(2000);
        cy.get('#txtf-883').type(Cypress.env('customerPassword'));
        cy.wait(1000);
        cy.get('#btn-377').should('be.enabled').click({force: true});
        cy.wait(2000);
        cy.completeOTP();

        cy.get('#btn-469').should('be.enabled').click()
        //Removed as the screen nnow proceeds on blur of the lasts text fields on OTP

         
        cy.wait(10000);
    });
});
