//import "./login.spec"
import "./commands"
const airtimeAmt = 5;
const house = "78";
const street = "East Str";
const suburb = "EAST Town";
const city = "Randburg";
const postalCode = "2195";
const occupation = "ACCOUNTANT";
const industry = "PERS ACCOUNTS-INDIV - TECH, SPECIALIST";
const sourceOfIncome = "SALARY EARNER";


describe("Customer Profile", function () {

    beforeEach(function () {
           cy.customerloign();
           cy.restoreLocalStorageCache();

       });


    it('Edits residential details', function () {
//            cy.visit('/dashboard/v1/customer/board');
            cy.wait(5000);
            cy.contains('More').click({force: true});
            cy.wait(10000);

            cy.xpath('//*[@id="scrollingContent"]/div/div[1]/span/div/ui-svg').click({force:true});
            cy.wait(4000);
            cy.xpath('//*[@id="scrollingContent"]/div/ui-skeleton-screen/div[3]/div[5]/ui-svg').click({force:true});
            cy.wait(10000);

//            cy.get('#txtf-742').click({force:true});
//            cy.wait(9000);

            cy.get('input[name=house]').clear().type(house);
            cy.get('input[name=street]').clear().type(street);

            cy.get('input[name=suburb]').click();
            cy.get('input[name=suburb]').clear().type(suburb);
            cy.wait(3000);
            cy.xpath('//*[@id="scrollingContent"]/div/ui-labeled-input/div[2]/div/div/p').click();

            cy.contains('button', ' UPDATE ').click();
            cy.wait(3000);

            cy.completeOTP();
            cy.wait(1000);
            cy.get('#btn-981').click();
//            cy.wait(15000);
//
//            cy.get('#btn-451').click();
//
//            cy.completeOTP();
           /* cy.get('#btn-981').click();
            cy.wait(15000);
            cy.contains(Cypress.env('customerUsername')).should('be.visible');*/


     })

     it('Edits employment details', function () {
//         cy.visit('/dashboard/v1/customer/board');
         cy.wait(5000);
         cy.contains('More').click({force: true});
         cy.wait(10000);

         cy.xpath('//*[@id="scrollingContent"]/div/div[1]/span/div/ui-svg').click({force:true});
         cy.wait(4000);

         cy.xpath('//*[@id="scrollingContent"]/div/ui-skeleton-screen/div[4]/div/ui-svg').click({force:true});
         cy.wait(9000);
         //cy.xpath('//*[@id="scrollingContent"]/ui-labeled-input[2]/div[1]/input').click({force:true});
         cy.get('#txtf-1077').click();
         cy.contains(occupation).click();

         cy.get('input[name=industry]').click();
         cy.contains(industry).click();

         cy.get('input[name=sourceOfIncome]').click();
         cy.contains(sourceOfIncome).click();

          cy.get('#btn-451').click();
          cy.wait(3000);

          cy.completeOTP();
          cy.wait(2000);
          cy.get('#btn-981').click();
//          cy.wait(15000);

//                  cy.completeOTP();
//                  cy.contains('button', ' Confirm PIN ').click();
//                  cy.wait(15000);
//          cy.contains(Cypress.env('customerUsername')).should('be.visible');

     });

     it('Edits contact details', function () {
//          cy.visit('/dashboard/v1/customer/board');
          cy.wait(5000);
          cy.contains('More').click({force: true});

          cy.wait(5000);
          cy.xpath('//*[@id="scrollingContent"]/div/div[1]/span/div/ui-svg').click({force:true});
          cy.wait(5000);
          cy.xpath('//*[@id="scrollingContent"]/div/ui-skeleton-screen/div[3]/div[1]/ui-svg').click({force:true});
          cy.contains('button', ' SEND OTP ').click();
          cy.wait(2000);

          cy.completeOTP();
          cy.wait(3000);
          cy.get('#btn-981').click();

          cy.wait(5000);
          /*cy.completeSecondOTP();
          cy.wait(2000);
          cy.get('#btn-981').click();
          cy.wait(15000);
          cy.contains(Cypress.env('customerUsername')).should('be.visible');*/
          //====Press home button
          cy.contains('Home').click({force: true});

     });


})