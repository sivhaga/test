//import "./login.spec"
import "./commands"
var serviceseach = "Installer"
var projectName = "Pest Controller"
var projectDescription = "i need some spring cleaning"
const fileName = 'userproj.png';
const searchLocation = '5 East East Town';
const complex = 'Test Complex';
const streetNumber = '121';
const description = 'honk honk';
describe("SERVICES", function () {

   beforeEach(function () {
       cy.customerloign();
       cy.restoreLocalStorageCache();

   });

    afterEach(function() {
        cy.saveLocalStorageCache();
    });

//    it('Navigate to SERVICES screen', function () {
//        cy.wait(5000);
//        cy.contains('Categories').should('be.visible').click({force: true});
//        cy.wait(3000);
//        cy.contains('Services').click({force: true});
//        cy.wait(5000);
//    });
//
//    it('Validates SERVICES screen', function () {
//            cy.wait(5000);
//            cy.contains('Categories').should('be.visible').click({force: true});
//            cy.wait(3000);
//            cy.contains('Services').click({force: true});
//            cy.wait(5000);
//            cy.get('input').should('be.enabled');
//            cy.contains('Let\'s find the service you need');
//            cy.contains('Trending Service Category');
//            cy.contains('See more');
//            cy.contains('How it works?');
//            cy.wait(2000);
//        });

    it('Search for a SERVICE', function () {
            cy.wait(5000);
            cy.contains('Categories').should('be.visible').click({force: true});
            cy.wait(3000);
            cy.contains('Services').click({force: true});
            cy.wait(5000);
            cy.get('input').should('be.enabled');
            cy.contains('Let\'s find the service you need');
            cy.contains('Trending Service Category');
            cy.contains('See more');
            cy.contains('How it works?');
            cy.wait(2000);
            cy.get('input').should('be.enabled').click();
            cy.get('input').should('be.enabled').type('Installer{enter}');
//            cy.get('input').should('be.enabled').click();
            cy.xpath('//*[@id="scrollingContent"]/div/div[1]/wakanda-customer-search-item[1]/div/p').click({force: true});
            cy.wait(15000);
            cy.contains('in all Service');

       });

    it('Creates an job service advert', function () {
                cy.wait(5000);
                cy.contains('Categories').should('be.visible').click({force: true});
                cy.wait(3000);
                cy.contains('Services').click({force: true});
                cy.contains('Cleaning & Pest Control').click({force: true});
                cy.wait(2000);
                cy.get('#txtf-1144').type(projectName);
                cy.contains('Is it urgent?').click({force: true});
                cy.get('#txtf-1915').type(projectDescription);

//                cy.fixture(fileName).then(fileContent => { //uploading image
//                  cy.xpath('/html/body/wakanda-root/app-main-layout-with-navigation/main/ng-component/ui-container/div/div/div/wakanda-customer-order-a-service-create-job-add-images/div/ui-image-preview').upload({ fileContent, fileName, mimeType: 'image/png' });
//                });

                cy.get('#btn-834').should('be.enabled').click(); //add location
                cy.wait(2000);
                cy.contains('Add new address').click({force: true});
                cy.wait(3000);
                cy.get('#txtf-1455').clear().type(searchLocation);
                cy.wait(15000);
                cy.contains('5 East Street').click({force: true});
                cy.wait(15000);

                cy.get('#txtf-760').type(complex);
                cy.get('#txtf-1280').type(streetNumber);
                cy.get('#txtf-611').type(description);
                cy.get('#btn-303').should('be.enabled').click(); // button save
                cy.wait(10000);

                cy.xpath('//*[@id="scrollingContent"]/div/wakanda-customer-order-a-service-location-item[1]/div').click({force: true});

                cy.get('#btn-319').should('be.enabled').click(); //next button
                cy.get('#btn-577').should('be.enabled').click(); //postjob button
                cy.wait(15000);
                cy.contains(' CHAT ');


           });

 /*it('Edit delivery address for a job service advert', function () {
                cy.visit('/dashboard/v1/customer/board');
                cy.wait(10000);
                cy.contains('Services').click({force: true});
                cy.contains('Pet and Animal Services').click({force: true});
                cy.wait(2000);
                cy.get('input[name=projectName]').type(projectName);
                cy.xpath('//*[@id="scrollingContent"]/ui-checkbox/div/span/ui-svg').click();
                cy.xpath('//*[@id="scrollingContent"]/ui-labeled-input[2]/div[1]/textarea').type(projectDescription);

                cy.fixture(fileName).then(fileContent => {
                  cy.xpath('//*[@id="scrollingContent"]/wakanda-customer-order-a-service-create-job-add-images/input').upload({ fileContent, fileName, mimeType: 'image/png' });
                });

                cy.get('button').should('be.enabled').click();  //add location button
                cy.wait(2000);
                cy.xpath('//*[@id="scrollingContent"]/div[1]/wakanda-customer-order-a-service-location-item[1]/div/ui-svg[1]').click({force: true}); //Edit address button

                cy.xpath('//*[@id="scrollingContent"]/wakanda-customer-order-a-service-create-job-pick-address/wakanda-customer-order-a-service-create-job-set-location/ui-make-search-map/ui-select/div/div[2]/div[1]/span/p[2]').click({force: true});
                cy.get('input[name=complex]').type(complex);
                cy.get('input[name=streetNumber]').type(streetNumber);
                cy.get('input[name=saveAs]').type(description);

                cy.xpath('//*[@id="scrollingContent"]/ui-button/button').click({force: true});

                cy.wait(12000);
                cy.xpath('//*[@id="scrollingContent"]/wakanda-customer-order-a-service-create-job-pick-address/div[1]/wakanda-customer-order-a-service-location-item[1]/div/ui-radio/div/span/i').click({force: true});

                cy.xpath('//*[@id="scrollingContent"]/wakanda-customer-order-a-service-create-job-pick-address/div[2]/ui-button/button').click({force: true});
                cy.wait(10000);
                cy.xpath('//*[@id="scrollingContent"]/ui-button/button').click({force: true});
                cy.wait(15000);
                //cy.contains('We have found');


           });*/

});