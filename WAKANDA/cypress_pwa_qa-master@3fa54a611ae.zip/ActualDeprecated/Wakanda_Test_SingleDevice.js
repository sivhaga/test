const device_sizes = [ 'iphone-6', 'ipad-2', [1024, 768]]

describe("To Demo Cypress on PWA", function(){

    beforeEach(function(){
        cy.visit('https://pwa.wakago.net/wakanda-customer/index.html')
    })
        it.only('Search for a service for device ${device_size}', function(){    
                cy.viewport('iphone-6+')

            cy
            .get('body > wakanda-merchant-root > app-main-layout-with-navigation > main > div > ng-component > my-money-buttons > div > span:nth-child(1) > button')
            .click()
    
            cy
            .get('body > wakanda-merchant-root > app-main-layout-with-navigation > main > div > ng-component > ui-switch-button > div > button:nth-child(1)')
            .click()
    
            cy.get('input[name=amount]').type(1200)
    
            cy.get('input[name=from]').type('Account Payment').should('have.value', 'Account Payment')
    
            cy.get('input[name=description]').type('To get account').should('have.value', 'To get account')
    
            cy.get('input[name=reference]').type('INV/123009').should('have.value', 'INV/123009')
    
            cy
            .get('body > wakanda-merchant-root > app-main-layout-with-navigation > main > div > ng-component > ui-container > div > wakanda-merchant-my-money-accept-request-money > ui-segment > div > form > ui-toggle > div > label > span')
            .click()
    
            cy.contains('AFTER 1 DAY').click()
    
            cy
            .get('body > wakanda-merchant-root > app-main-layout-with-navigation > main > div > ng-component > ui-container > div > wakanda-merchant-my-money-accept-request-money > ui-segment > div > button')
            .click()
    
            cy.get('body > wakanda-merchant-root > app-main-layout-with-navigation > main > div > ng-component > ui-container > div > ui-segment > div > div').click()
    
            cy.contains('Payment link generated!')
    
            // cy
            // .get('body > wakanda-merchant-root > app-main-layout-with-navigation > main > div > ng-component > ui-container > div > ui-segment > div > button:nth-child(3)')
            // .click()
        })
})