//import "./login.spec";
import "./commands";
describe("Buy groceries", function () {

    beforeEach(function () {
        cy.customerloign();
        cy.restoreLocalStorageCache();

    });

    afterEach(function() {
        cy.saveLocalStorageCache();
    });

    it('Navigate to OneCart', function () {
        cy.get('#elem-931').click({force: true});
        cy.wait(20000);
        cy.contains('SHOP GROCERIES').click({force: true});
    });

    it('Validates Free delivery Message, Coupon Text', function () {
        cy.get('#elem-931').click({force: true});
        cy.wait(10000);
        cy.contains(' SHOP GROCERIES ').click({force: true});
        cy.get('.info').find('h3').should('have.text', "Your delivery is on us!");
        //cy.get('.info').find('p').should('have.text', 'Just use "FreeDelivery" coupon code when you checkout!');  //This have been removed
    });

    it('Validates that it can click and see Privacy Policy', function(){
        cy.get('#elem-931').click({force: true});

        cy.contains(' SHOP GROCERIES ').click({force: true});
        cy.wait(10000);
        cy.contains('See Privacy Policy').click();
        cy.wait(16000);
        cy.contains('PRIVACY POLICY');
        cy.url().should('include', '/my-profile/tc/pp');

        cy.get('.pdf-wrapper').find('iframe').then(function ($iframe) {
            var body = $iframe.contents().find('body');
            cy.wrap(body).contains("PRIVACY NOTICE");
        });
    });

    it('Navigates back to Groceries', function() {
        cy.get('#elem-931').click({force: true});
        cy.contains(' SHOP GROCERIES ').click({force: true});
        cy.wait(15000);
        cy.get('#btn-1021').should('be.enabled').click();
    });

    it('Validates that User is Auto Signed In (Sign In Button Should not Exist)', function () {
       cy.get('#elem-931').click({force: true});
        cy.contains(' SHOP GROCERIES ').click({force: true});
        cy.wait(15000);
        cy.get('#btn-1021').should('be.enabled').click();
        cy.wait(15000);
        cy.get('iframe').first().then(function ($iframe) {
            var body = $iframe.contents().find('body');
            cy.wrap(body).contains('sign in');
        });
    });
});