describe("Buy product", function () {

    before(function () {
        cy.fixture('buyProduct').then(function (data) {
            this.data = data
        })

    })

    beforeEach(function () {
        cy.visit('https://www.soko.life/home')
        cy.wait(2000)
        cy.contains('button', 'LET’S GET STARTED').click()
        cy.get('.home.filter-buttons').find('ui-button').eq(0).click()
    })

    it('Search results not found', function () {
        cy.get('.ui.select').find('input').click()
        // cy.contains("TRENDING")
        // cy.contains("RECENT")
        cy.get('.ui.select').find('input').type('slkkjjj')
        cy.contains("No results for slkkjjj!")

    })

    it('Search for a product', function () {
        cy.get('.ui.select').find('input').click()
        // cy.contains("TRENDING")
        // cy.contains("RECENT")
        cy.get('.ui.select').find('input').type('shoes')
    })

    // it('Shopping - products', function () {
    //     cy.get('.action-button').find('button').eq(0).click()
    //     cy.get('.header-title').should('have.text', "SHOPPING")

    //     cy.get('.title-block')
    //         .find('h3')
    //         .eq(0)
    //         .should('have.text', "Shop By Category")

    //     cy.get('.title-block')
    //         .find('h3')
    //         .eq(1)
    //         .should('have.text', 'New arrivals')
    //     z
    //     cy.get('.title-block')
    //         .find('h3')
    //         .eq(2)
    //         .should('have.text', 'Shop by look')
    // })

    // it('Shopping - utilities', function () {
    //     cy.get('.action-button')
    //         .find('button')
    //         .eq(1)
    //         .click()

    //     cy.get('.header-title').should('have.text', "Utilities")

    //     cy.get('.title-block')
    //         .find('h3')
    //         .eq(0)
    //         .should('have.text', "Shop By Category")

    //     cy.get('.title-block')
    //         .find('h3')
    //         .eq(1)
    //         .should('have.text', 'New arrivals')

    //     cy.get('.title-block')
    //         .find('h3')
    //         .eq(2)
    //         .should('have.text', 'Shop by look')
    // })

    // it('Shopping cart - view', function () {
    //     cy.get('i.icon.my-cart').click()

    //     cy.get('.header-title').
    //         eq(0)
    //         .should('have.text', "MY CART")

    //     cy.get('.ui-step-progress-bar')
    //         .find('li')
    //         .should('have.length', '4')

    //     cy.get('.waka-points')
    //         .find('span.description')
    //         .find('h4').contains("90 WakaPoints")

    //     cy.get('.promo').find('a').contains("APPLY A PROMOCODE")
    //     cy.get('.loans')
    //         .find('.get-personal-loan')
    //         .find('span.description')
    //         .find('h4')
    //         .contains("Get a Personal Loan for all your purchases!")

    //     cy.get('.subtotal')
    //         .find('.description')
    //         .find('h3')
    //         .contains("Cart Subtotal")

    //     cy.contains('button', 'CHECKOUT')
    //     cy.get('.product')
    //         .find('.title')
    //         .find('h3')
    //         .contains("SAVED FOR LATER")
    // })

    // it('Shopping cart - add delivery address', function () {
    //     cy.get('i.icon.my-cart').click()
    //     cy.get('.promo')
    //         .find('a')
    //         .contains("APPLY A PROMOCODE")

    //     cy.get('.promo')
    //         .find('a')
    //         .contains("APPLY A PROMOCODE").click()

    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('h3').contains("Available promocodes")

    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('.promo-code.ng-star-inserted')
    //         .eq(0)
    //         .find('span.description')
    //         .find('h4').contains("10% off each")

    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('.promo-code.ng-star-inserted')
    //         .eq(0).find('span.description')
    //         .find('p')
    //         .contains("10% off each item for 3 or more items (excluding shipping)")

    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('.promo-code.ng-star-inserted')
    //         .eq(1).find('span.description')
    //         .find('h4')
    //         .contains("Half Off")

    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('.promo-code.ng-star-inserted')
    //         .eq(1).find('span.description').find('p')
    //         .contains("Half Off if total is 2000 or more (excluding shipping)")

    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('.promo-code.ng-star-inserted')
    //         .eq(2).find('span.description')
    //         .find('h4').contains("20% off Cart total")

    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('.promo-code.ng-star-inserted')
    //         .eq(2).find('span.description')
    //         .find('p')
    //         .contains("20% off Cart total if shipping within South Africa (including shipping)")

    //     cy.get('ui-labeled-input')
    //         .find('.labeled-input')
    //         .find('input').type('walter')

    //     cy.contains('button', 'APPLY PROMOCODE').click()

    //     cy.get('.promo')
    //         .find('a')
    //         .contains("APPLY A PROMOCODE")

    //     cy.get('.header-title')
    //         .eq(0).should('have.text', "MY CART")

    //     cy.contains('button', 'CHECKOUT').click()
    //     cy.get('.header-title')
    //         .eq(0)
    //         .should('have.text', "CHOOSE DELIVERY METHOD")

    //     cy.get('.delivery-info-row.ng-star-inserted')
    //         .find('h3').contains("Add new address")
    //     cy.get('.delivery-info-row.ng-star-inserted')
    //         .find('h3')
    //         .contains("Add new address")
    //         .click()
    // })

    // it('Shopping cart - pickup store', function () {
    //     cy.get('i.icon.my-cart').click()
    //     cy.get('.promo')
    //         .find('a')
    //         .contains("APPLY A PROMOCODE")

    //     cy.get('.promo')
    //         .find('a')
    //         .contains("APPLY A PROMOCODE")
    //         .click()

    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('h3')
    //         .contains("Available promocodes")

    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('.promo-code.ng-star-inserted')
    //         .eq(0).find('span.description')
    //         .find('h4')
    //         .contains("10% off each")

    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('.promo-code.ng-star-inserted')
    //         .eq(0).find('span.description')
    //         .find('p')
    //         .contains("10% off each item for 3 or more items (excluding shipping)")


    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('.promo-code.ng-star-inserted')
    //         .eq(1).find('span.description')
    //         .find('h4')
    //         .contains("Half Off")

    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('.promo-code.ng-star-inserted')
    //         .eq(1).find('span.description')
    //         .find('p')
    //         .contains("Half Off if total is 2000 or more (excluding shipping)")


    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('.promo-code.ng-star-inserted').eq(2
    //         ).find('span.description')
    //         .find('h4')
    //         .contains("20% off Cart total")

    //     cy.get('ui-segment')
    //         .find('.segment.padded')
    //         .find('.promo-code.ng-star-inserted')
    //         .eq(2).find('span.description')
    //         .find('p')
    //         .contains("20% off Cart total if shipping within South Africa (including shipping)")

    //     cy.get('ui-labeled-input')
    //         .find('.labeled-input')
    //         .find('input')
    //         .type('walter')

    //     cy.contains('button', 'APPLY PROMOCODE').click()
    //     cy.get('.promo')
    //         .find('a')
    //         .contains("APPLY A PROMOCODE")

    //     cy.get('.header-title')
    //         .eq(0)
    //         .should('have.text', "MY CART")

    //     cy.contains('button', 'CHECKOUT').click()
    //     cy.get('.header-title')
    //         .eq(0)
    //         .should('have.text', "CHOOSE DELIVERY METHOD")

    //     cy.get('.delivery-info-row.ng-star-inserted')
    //         .find('h3')
    //         .contains("Pickup from store")

    //     cy.get('.delivery-info-row.ng-star-inserted')
    //         .find('h3')
    //         .contains("Pickup from store")
    //         .click()

    //     cy.get('.header-title')
    //         .eq(0)
    //         .should('have.text', "SELECT PICKUP LOCATION")

    // })

})