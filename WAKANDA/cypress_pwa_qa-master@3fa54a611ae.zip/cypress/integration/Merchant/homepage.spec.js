import "../customer/commands";
//import "./merchant.login.spec";

describe("Merchant-Homepage", function () {

    beforeEach(function () {
        cy.merchantloign();
        cy.restoreLocalStorageCache();
    });

    after(function() {
        cy.saveLocalStorageCache();
        cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
        cy.wait(5000);
        cy.contains('LOGOUT').scrollIntoView()
        cy.contains('LOGOUT').should('be.visible').click({force: true});
    });

    it('Validates merchant homepage', function () {
        cy.wait(5000);
        cy.contains(' Today ').should('be.visible');
        cy.contains(' This Week ').should('be.visible');
        cy.contains(' This Month ').should('be.visible');

        cy.contains('DISPLAY QR');
        cy.contains('Pending Payments');
        cy.contains('Pending Requests');
        cy.contains('PREPAID UTILITIES');
        cy.contains('Settled to Bank Account');
//        cy.contains('ACTIVE JOBS').should('be.visible');
//        cy.contains('JOB REQUESTS').should('be.visible');
//        cy.contains('PAYMENTS SUMMARY').should('be.visible');
//        cy.contains('Incoming Payments').should('be.visible');
        cy.wait(2000);

    })


});

