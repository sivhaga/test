//import "./login.spec"
import "./commands"
describe("Banking Services", function () {

    beforeEach(function () {
        cy.restoreLocalStorageCache();
    });

     beforeEach(function () {
            cy.customerloign();
            cy.restoreLocalStorageCache();

        });


    it('Navigate to Travel screen', function () {
        cy.wait(5000);
        cy.contains('Categories').should('be.visible').click({force: true});
        cy.wait(3000);
        //cy.contains('Entertainment').click({force: true}); Label name changed
        cy.contains('Travel').click({force: true});
        cy.wait(2000);
    });

    it('Book travel', function () {
            cy.wait(5000);
            cy.contains('Categories').should('be.visible').click({force: true});
            cy.wait(3000);
            //cy.contains('Entertainment').click({force: true}); Label name changed
            cy.contains('Travel').click({force: true});
            cy.wait(2000);
            cy.xpath('//*[@id="elem-2346"]/div[1]/img').click();
            cy.wait(2000);
            //=====page contents
            cy.contains('PRODUCT DETAILS').scrollIntoView()
            cy.contains('PRODUCT DETAILS').should('be.visible').scrollIntoView()
            cy.contains('WARRANTY DETAILS').should('be.visible');

            cy.get('#btn-516').click(); //buy now buttn
            cy.wait(5000);
            cy.contains('You earn ').should('be.visible');
            cy.contains('Use promo code').should('be.visible');
            cy.get('#btn-598').click() //Check out

            cy.customerDeliveryProcess(); //Delivery

    });
});