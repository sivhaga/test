    //import "./login.spec"
    import "./commands"
    var productname = "IPHONE"
    describe("Shopping", function () {

    beforeEach(function () {
           cy.customerloign();
           cy.restoreLocalStorageCache();

       });

    afterEach(function() {
        cy.saveLocalStorageCache();
    });

    it('Shopping TECH PRODUCTS', function () {

        cy.wait(8000);
        cy.contains('Categories').should('be.visible').click({force: true});
        cy.wait(3000);
        cy.contains('Categories').should('be.visible').click({force: true});
        cy.wait(3000);
        cy.contains('Shopping').click({force: true});
        //cy.wait(5000);

        cy.contains('Tech').click({force: true});
        cy.wait(2000);

         cy.contains('Tablets & Kindles').click({force: true});
         cy.wait(2000);

         cy.xpath('//*[@id="elem-2796"]/div[1]/img').click({force: true});
         //cy.wait(5000);

          cy.contains('Description');
    //        cy.contains('DELIVERY INFORMATION');
          cy.contains('WARRANTY DETAILS');
          cy.contains('Terms and Conditions');
          cy.contains('Payment reservation');
          cy.contains('Return Policy');
          cy.wait(2000);

          cy.get('#btn-516').click({force: true}); //buy now
          cy.wait(2000);

          cy.contains('DELETE');
          cy.contains('SAVE FOR LATER');
          cy.contains('Use promo code');
        //cy.contains('Get a personal loan to pay for this order');
          cy.contains(' CHECKOUT ');
          cy.wait(2000);


        //'Continue to "CHECKOUT"'
          cy.get('#btn-598').click({force: true});
          cy.wait(2000);


         cy.customerDeliveryProcess(); //Delivery


    });

      it('Tests Shopping Luggage Products', function () {
            cy.wait(8000);
            cy.contains('Categories').should('be.visible').click({force: true});
            cy.wait(3000);
            cy.contains('Shopping').click({force: true});
            cy.wait(5000);

            cy.contains('Luggage').click({force: true});
            cy.wait(2000);

            cy.contains('Travel Bags').click({force: true});
            cy.wait(3000);

             cy.xpath('//*[@id="elem-818"]/div[1]/img').click({force: true});
             cy.wait(2000);

              cy.contains('Description');
    //        cy.contains('DELIVERY INFORMATION');
              cy.contains('WARRANTY DETAILS');
              cy.contains('Terms and Conditions');
              cy.contains('Payment reservation');
              cy.contains('Return Policy');
              cy.wait(2000);

              cy.get('#btn-516').click({force: true}); //buy now
              cy.wait(2000);

              cy.contains('DELETE');
              cy.contains('SAVE FOR LATER');
              cy.contains('Use promo code');
            //cy.contains('Get a personal loan to pay for this order');
              cy.contains(' CHECKOUT ');
              cy.wait(2000);


            //'Continue to "CHECKOUT"'
              cy.get('#btn-598').click({force: true});
              cy.wait(2000);

             cy.customerDeliveryProcess(); //Delivery
      });

      //==========================================================
        it('Searches for a product', function () {
            cy.wait(8000);
            cy.contains('Categories').should('be.visible').click({force: true});
            cy.wait(3000);
            cy.contains('Shopping').click({force: true});
            cy.wait(3000);

            cy.get('input').should('be.enabled');
            cy.get('input').should('be.enabled').click();
            cy.get('input').should('be.enabled').type(productname).type('{enter}');
            cy.xpath('//*[@id="scrollingContent"]/div/div[1]/wakanda-customer-search-item[1]/div/p').click({force: true});
            cy.wait(5000);

            cy.contains('results in all Product').should('be.visible');

        });

      //========================================================== commented no longer availale
//      it('Filter products', function () {
//              cy.wait(8000);
//              cy.contains('Categories').should('be.visible').click({force: true});
//              cy.wait(3000);
//              cy.contains('Shopping').click({force: true});
//              cy.wait(3000);
//
//              cy.contains('Luggage').click({force: true});
//              cy.contains('Travel Bags').click({force: true});
//              cy.wait(1000);
//
//              cy.xpath('//*[@id="elem-1026"]/div[1]/img').click({force:true});
//              cy.contains('Filter').should('be.visible');
//              cy.contains('Sort by').should('be.visible');
//              //cy.xpath('/html/body/wakanda-root/app-main-layout/main/ui-tasks-handler/ui-failure-dialog/ui-modal/div/div/ui-svg').click({force:true});//Brokenhere poperror showing up
//              cy.contains('Popularity').click({force:true}); //sortby
//              cy.contains('Luggage').click({force:true});
//
//              cy.get('#btn-438').click({force: true}); //`Click search button
//              cy.wait(2000);
//
//
//          });

      //========================================================
      it('Add a product to FAVOURITES then Remove it from list', function () {
          cy.wait(8000);
          cy.contains('Categories').should('be.visible').click({force: true});
          cy.wait(3000);
          cy.contains('Shopping').click({force: true});
          cy.wait(1000);

          cy.contains('Luggage').click({force: true});
          cy.contains('Travel Bags').click({force: true});
          cy.wait(1000);

          cy.xpath('//*[@id="elem-1026"]/div[2]/div[1]/ui-svg').click({force:true});
          cy.wait(2000);

          cy.visit('/dashboard/v1/customer/board');


      });
      //==================================================================
      it('Selects "VIEW ALL" in a category', function () {
          cy.wait(8000);
          cy.contains('Categories').should('be.visible').click({force: true});
          cy.wait(3000);
          cy.contains('Shopping').click({force: true});
          cy.wait(3000);

          cy.contains('Tech').click({force: true});
          cy.contains('VIEW ALL').click({force: true});
          cy.wait(3000);

          cy.contains('PRODUCTS').should('be.visible');

      });
      //==================================================================
       it('Go to my orders and view completed/ongoing oder', function () {
          cy.contains('More').click({force: true});
          cy.wait(10000);

          cy.contains('My Orders').click({force:true});
          cy.wait(5000);
          cy.contains('Ongoing').should('be.visible');

          //cy.xpath('/html/body/wakanda-root/app-main-layout-with-navigation/main/ng-component/ui-container/div/div/div/div[2]/ui-skeleton-screen[1]/ui-item[1]/div/div/div').click({force:true}); //select an order
          //broken cant vieww an order

       })




    });