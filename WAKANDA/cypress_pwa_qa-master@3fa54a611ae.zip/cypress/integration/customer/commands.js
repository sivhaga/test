let LOCAL_STORAGE_MEMORY = {};
var baseUrl = Cypress.env("merchantBaseUrl");

Cypress.Commands.add("saveLocalStorageCache", () => {
    Object.keys(localStorage).forEach(key => {
        LOCAL_STORAGE_MEMORY[key] = localStorage[key];
    });
});

Cypress.Commands.add("restoreLocalStorageCache", () => {
    Object.keys(LOCAL_STORAGE_MEMORY).forEach(key => {
        localStorage.setItem(key, LOCAL_STORAGE_MEMORY[key]);
    });
});

Cypress.Commands.add("completeOTP", function() {
    var i = 1;
    cy.get(Cypress.env("otpScreenFields")).each(function($digits, i)  {
        i = i + 1;
        cy.wrap($digits).find('input').type(i);
    });
    cy.log(i);
});

Cypress.Commands.add("completeSecondOTP", function () {
    var j = 1;
    cy.get(Cypress.env("otpScreenFields")).each(function ($digit, j) {

        j = j - 4;
        cy.wrap($digit).find('input').type(j,{force:true});
    });
    cy.log(j);
});

Cypress.Commands.add("merchantLogOut", function () {
    cy.contains("MY ACCOUNT").click({ force: true });
    cy.wait(2000);
    cy.contains("Logout").click();
});

Cypress.Commands.add("merchantloign", function () {

   cy.visit(baseUrl);
   cy.wait(4000);
   var returnedUrl = "";
    cy.url().then(url => {
      returnedUrl = url;
      if(returnedUrl == 'https://pwa-merchant-stage.wakago.net/private/login'){
             cy.get('input[name=username]').type(Cypress.env('privateLoginUsername'));
             cy.get('input[name=password]').type(Cypress.env('privateLoginPassword'));
             cy.get('#btn-377').click();

             returnedUrl = "";
       };
    });

    var returnedUrl = "";
            cy.url().then(url => {
              returnedUrl = url;
              if(returnedUrl == 'https://pwa-merchant-stage.wakago.net/home'){
                     cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
                     cy.wait(5000);
                     cy.contains('LOGOUT').scrollIntoView()
                     cy.contains('LOGOUT').should('be.visible').click({force: true});

                    returnedUrl = "";
               };
            });

    var returnedUrl = "";
            cy.url().then(url => {
              returnedUrl = url;
              if(returnedUrl == 'https://pwa-merchant-stage.wakago.net/enrollment'){
                     cy.contains('button', 'Let\'s get started').click();

                    returnedUrl = "";
               };
    });

   cy.wait(2000);
   cy.get('input[name=username]').type(Cypress.env('merchantUsername'));
   cy.wait(1000);
   cy.get('#btn-377').should('be.enabled').click();
   cy.wait(2000);
   cy.get('input[name=password]').type(Cypress.env('merchantPassword'));
   cy.wait(1000);
   cy.contains('button', 'LOGIN').should('be.enabled').click({force: true});
   cy.wait(2000);
   cy.completeOTP();
   /**
    * cy.contains('button', 'LOGIN').should('be.enabled').click()
    * Removed as the screen nnow proceeds on blur of the lasts text fields on OTP
    */

    cy.get('#btn-469').click();

   cy.wait(15000);
});

Cypress.Commands.add("customerloign", function () {
   cy.visit("/");
   cy.wait(5000);
//   cy.get('#txtf-520').type('test@nedbank.co.za');
//   cy.get('#btn-468').should('be.enabled').click({force: true});
//   cy.get('#btn-1590').should('be.enabled').click({force: true}); //Let\'s get started'
   cy.get('#btn-409').should('be.enabled').click({force: true}); //LOgin
   cy.wait(1000);
   //cy.contains('button', 'LOG IN').click();
   cy.get('#txtf-864').type(Cypress.env('customerUsername'));
   cy.wait(1000);
   cy.get('#btn-377').should('be.enabled').click(); //button
   cy.wait(2000);
   cy.get('#txtf-883').type(Cypress.env('customerPassword'));
   cy.wait(1000);
   cy.get('#btn-377').should('be.enabled').click({force: true});
   cy.wait(2000);
   cy.completeOTP();

   cy.get('#btn-469').should('be.enabled').click()
   //Removed as the screen nnow proceeds on blur of the lasts text fields on OTP

   cy.wait(15000);
});

Cypress.Commands.add("customerEmailLogin", function () {

   cy.get('#txtf-520').type('test@nedbank.co.za');
   cy.get('#btn-468').should('be.enabled').click({force: true});
   cy.get('#btn-1590').should('be.enabled').click({force: true}); //Let\'s get started'
   cy.get('#btn-409').should('be.enabled').click({force: true}); //LOgin
   /*cy.on('fail', (err) => {  //If the above fails dont fail the test
      //debugger
    })*/

});

Cypress.Commands.add("merchantPrivateloign", function () {

   cy.visit(baseUrl);
   cy.wait(2000);
   cy.get('input[name=username]').type(Cypress.env('privateLoginUsername'));
   //cy.skipOn('fail');
      cy.on('fail', (err) => {  //If the above fails dont fail the test
            alert('//debugger');
          })
   cy.get('input[name=password]').type(Cypress.env('privateLoginPassword'));
   cy.get('#btn-377').click();

   cy.contains('button', 'Let\'s get started').click();



});

Cypress.Commands.add("customerDeliveryProcess", function () {

   //'Validates "Delivery Address" page contents', function () {
             cy.contains('Delivery addresses');
             cy.contains(' DELIVER HERE ');
             cy.contains('Use this address for billing address');
             cy.contains('Add new address');
             cy.contains('Add locker location');
             cy.wait(5000);

             cy.get('#btn-847').should('be.enabled').click();;
             cy.wait(5000);


           //'Validates "Payment" page contents'
             cy.contains('Delivery charge');
             cy.contains('Total');
             cy.contains(' PROCEED TO PAYMENT ');
             cy.wait(2000);

           //'PROCEED TO PAYMENT '
             cy.get('#btn-1283').should('be.enabled').click();
             cy.wait(2000);


           //'Validates second "Payment" page contents', function () {
             cy.contains('Total');
             cy.contains('Use promo code');
             //cy.contains('Get a personal loan to pay for this order');
             cy.contains('Use your AVO Points!');
             //cy.contains('Wallet balance');
             cy.wait(2000);

          //'Confirm purchase', function () {
             cy.get('button').should('be.enabled').click(); //button id changes dynamic
             cy.completeOTP();
             cy.get('#btn-981').click();
             cy.wait(5000);
             cy.contains('Payment reserved!').should('be.visible');

});