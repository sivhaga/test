import "./commands";
var current_view_port;
var baseUrl = Cypress.env("customerLoginUrl");
var device_sizes = Cypress.env("deviceSizes");

afterEach(function() {
    cy.saveLocalStorageCache();
});

describe("Avo User Private Login", function () {
    it("Does Private Login", function () {
        cy.visit("/");
       /* cy.wait(2000);
        cy.get('input[name=username]').type(Cypress.env('privateLoginUsername'));
        cy.get('input[name=password]').type(Cypress.env('privateLoginPassword'));
        cy.contains('button', 'CONTINUE').click();
        cy.contains('button', 'Let\'s get started').click();*/
    });
});
