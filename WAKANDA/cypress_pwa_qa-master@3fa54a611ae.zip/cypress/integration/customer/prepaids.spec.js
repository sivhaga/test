//import "./login.spec"
import "./commands"
const avoOneCartInfos = ["Name and surmane", "Cellphone Number", "Saved addresses", "Email address"]
const airtimeAmt = 5;
const reference = 'TESTING123';
const meterNumber = '000001022006';
const electrAmt = 20;
const requestPaymentPhoneNumber = 769000357;
describe("Buy prepaid services", function () {

    beforeEach(function () {
           cy.customerloign();
           cy.restoreLocalStorageCache();

       });


    it('Buys Prepaid Airtime', function () {
        cy.wait(2000)
        cy.get('#elem-824').click({force: true})
        cy.wait(3000)

        cy.contains('Airtime & Data').click({ force: true });
        cy.wait(15000)

        cy.contains('Who would you like to buy airtime or data for?');

        cy.get('#txtf-538').type(requestPaymentPhoneNumber);

        cy.get('#btn-1496').should('be.visible').click();

        cy.contains('Choose a provider');
        cy.contains('Vodacom').click({ force: true });
        cy.contains('Airtime').click({ force: true });
        cy.contains(' Own amount ').click({ force: true });
        cy.get('#txtf-1295').type(airtimeAmt);

        cy.get('#btn-549').should('be.visible').click()
        cy.wait(1000);

        cy.get('#txtf-1188').type(reference);
        cy.get('#btn-718').should('be.enabled').click();
        cy.wait(22000);
        cy.contains('Purchase successful!'); //will changeit when fixed
        cy.get('#btn-904').should('be.enabled').click();

    })

    it('Buys Data Bundles', function () {
            cy.wait(2000)
            cy.get('#elem-824').click({force: true})
            cy.wait(3000)

            cy.contains('Airtime & Data').click({ force: true });
            cy.wait(15000)

            cy.contains('Who would you like to buy airtime or data for?');

            cy.get('#txtf-538').type(requestPaymentPhoneNumber);

            cy.get('#btn-1496').should('be.visible').click();

            cy.contains('Choose a provider');
            cy.contains('Vodacom').click({ force: true });
            cy.contains('Data').click({ force: true });
            cy.contains(' Bundle ').click({ force: true });
            cy.contains('See all bundles').click({ force: true });
            cy.contains(' Vodacom Prepaid Data Bundle 50 MB ').click({ force: true });

            //cy.contains('button', ' BUY R' + airtimeAmt + '.00 ').click()
            cy.get('button').should('be.enabled').click();
            cy.wait(1000);

            cy.get('input[name=description]').type(reference);
            cy.get('button').should('be.enabled').click();
            cy.wait(22000);
            cy.contains('Purchase successful!'); //will changeit when fixed
            cy.get('#btn-904').should('be.enabled').click();

        })

        it('Buys Prepaid Electricity', function () {


                      cy.get('#elem-824').click({force: true})
                      cy.wait(3000)

                      cy.contains('Electricity').click({ force: true });
                      cy.wait(15000)

                      cy.get('#txtf-1469').type(requestPaymentPhoneNumber);
                      cy.get('#txtf-1158').type(meterNumber);
                      cy.get('#txtf-660').type(electrAmt);
                      cy.wait(10000);

                      cy.get('#btn-446').should('be.enabled').click();

                      cy.contains('Total Payable Amount');
                      cy.contains('R' + electrAmt + '.00');

                      cy.get('button').should('be.enabled').click();
                      cy.wait(15000);

                      cy.contains('Payment Successful!');
                      cy.contains('Reference number');
                      cy.contains(' CLOSE ').click();

         })

        it('Repeat Recent Prepaid Electricity purchase', function () {
                      cy.wait(3000);
                      cy.get('#elem-824').click({force: true})
                      cy.wait(3000);

                      cy.contains('Electricity').click({ force: true });
                      cy.wait(5000);

                      cy.xpath('//*[@id="scrollingContent"]/div[1]/span[1]/div').click();;
                      cy.wait(5000);

                      cy.get('button').should('be.enabled').click();
                      cy.wait(15000);

                      cy.contains('Payment Successful!');
                      cy.screenshot('Electricity purchase success');
                      cy.contains('Reference number');
                      cy.contains(' CLOSE ').click();

        })

})