describe("/profile", function () {

    before(function () {
        cy.fixture('wallet.json').then(function (data) {
            this.data = data
        })
    })

    beforeEach(function () {
        cy.visit('https://soko.life')
        cy.wait(2000)
        cy.contains('button', 'LET’S GET STARTED').click()
        cy.scrollTo(0, 600)
        cy.get('div#4.item').click()
    })

    it('view profile picture', function () {
        cy.get('.row.padded-content').click()
        cy.get('.header-title').should('have.text', "EDIT PROFILE")
        cy.contains("CONTACT DETAILS")
        cy.contains("Cellphone No")
        cy.contains("Email Id")
        cy.contains("Residential address")
        cy.contains("OTHER DETAILS")
        cy.contains("Display name")
        cy.contains("Occupation")
        cy.contains("Industry")
        cy.contains("Job")
    })

    it('edit cell number', function () {
        cy.get('.row.padded-content').click()
        cy.get(':nth-child(5) > .icon').click()
        cy.get('.header-title').should('have.text', "Cellphone Number")
        cy.get('input[name="undefined"]').clear()
        cy.get('input[name="undefined"]').type("27731264534")
        cy.contains('button', 'GENERATE OTP').click()

        cy.get('.ui.pin-wrapper').find('span.pin-item').find('input')
            .eq(0).click().type(1)

        cy.get('.ui.pin-wrapper').find('span.pin-item')
            .find('input').eq(1).click().type(2)

        cy.get('.ui.pin-wrapper').find('span.pin-item')
            .find('input').eq(2).click().type(3)

        cy.get('.ui.pin-wrapper').find('span.pin-item')
            .find('input').eq(3).click().type(4)

        cy.get('.ui.pin-wrapper').find('span.pin-item')
            .find('input').eq(3).click().type(5)

        cy.contains('button', 'VERIFY').click()

    })

    it('edit residentail address', function () {
        cy.get('.row.padded-content').click()
        cy.get(':nth-child(13) > .icon').click()
        cy.get('.header-title').should('have.text', "RESIDENTIAL ADDRESS")
        cy.contains("Where do you live?")
        cy.get('input[name="complex"]').clear().type("105 West")
        cy.get('input[name="streetName"]').clear().type("West")
        cy.get('input[name="locality"]').clear().type("Sandown")
        cy.get('input[name="city"]').clear().type("Randburg")
        cy.get('input[name="postalCode"]').clear().type("4534")
        cy.contains('button', 'SAVE').click()

    })


    it('edit other details', function () {
        cy.get('.row.padded-content').click()
        cy.get(':nth-child(16) > .icon').click()
        cy.get('.header-title').should('have.text', "OTHER DETAILS")
        cy.get('input[name="username]').clear().type("Jabu")
        cy.get('input[name="occupation"]').clear().type("QA Engineer")
        cy.get('input[name="sourceOfIncome"]').clear().type("Salary")
        cy.contains('button', 'SAVE').click()

    })

    it('Saved accounts and cards profile menu - funding methods', function () {
        cy.contains("Saved Accounts & Cards")
        cy.get(':nth-child(3) > :nth-child(4)').click()
        cy.get('.header-title').should('have.text', "SAVED ACCOUNTS AND CARDS")
        cy.contains('button', " FUNDING METHODS ")
        cy.contains('button', 'WITHDRAWAL METHODS')
        cy.contains("You don’t have any saved accounts or cards!")
        cy.contains("ADD A FUNDING METHOD")
    })

    it('Saved accounts and cards profile menu - withdrawal methods', function () {
        cy.contains("Saved Accounts & Cards")
        cy.get(':nth-child(3) > :nth-child(4)').click()
        cy.contains('button', 'WITHDRAWAL METHODS').click()
        cy.contains("You don’t have any saved accounts or cards!")
        cy.contains("Add Withdrawal Bank Account")
    })

    it('My rewards profile menu', function () {
        cy.contains("My Rewards")
        cy.get(':nth-child(5) > :nth-child(2)').click()
        cy.get('.header-title').should('have.text', "My Rewards")

    })

    it('Addresses profile menu', function () {
        cy.contains("Addresses")
        cy.get(':nth-child(5) > :nth-child(4)').click()
        cy.get('.header-title').should('have.text', "ADDRESSES")
        cy.contains("No addresses have been saved yet!")
        cy.contains('button', ' ADD NEW ADDRESS ').click()
    })

    it('Favourites profile menu', function () {
        cy.contains("Favourites")
        cy.get(':nth-child(5) > :nth-child(2)').click()
        cy.get('.header-title').should('have.text', "Favourites")

    })

    it('My orders profile menu', function () {
        cy.contains("My Orders")
        cy.get(':nth-child(5) > :nth-child(8)').click()
        cy.get('.header-title').should('have.text', "My Orders")
    })


    it('Settings profile menu - view', function () {
        cy.contains("Settings")
        cy.get(':nth-child(7) > :nth-child(2)').click()
        cy.get('.header-title').should('have.text', "SETTINGS")
        cy.contains("Notification Settings")
        cy.contains("Change PIN")
        cy.contains("Change Password")
        cy.contains("Enable Device Biometrics")
    })

    it('Settings profile menu  - notification settings', function () {
        cy.contains("Settings")
        cy.get(':nth-child(7) > :nth-child(2)').click()
        cy.get('.segment > :nth-child(1)').click()
        cy.contains("Notifications about your account, app updates and support requests")
        cy.contains("Promotional Notifications")
        cy.contains("Order Related Notifications")
    })

    it('settings profile menu  - change pin', function () {
        cy.contains("Settings")
        cy.get('.segment > :nth-child(3)').click()
        cy.get('.header-title').should('have.text', "Change PIN")

    })

    it('settings profile menu - change password', function () {
        cy.contains("Settings")
        cy.get(':nth-child(7) > :nth-child(2)').click()
        cy.contains("Change Password")
        cy.get('.segment > :nth-child(5)').click()
        cy.get('.header-title').should('have.text', "Change password")
        cy.get('input[name="currentPassword"]').type('Testing@01')
        cy.contains('button', ' next ').click()
        cy.get('input[name="newPassword"]').type('Testing@01')
        cy.get('input[name="reEnterNewPassword"]').type('Testing@01')
        cy.contains('button', ' update password ').click()
    })

    it('refer a friend profile menu', function () {
        cy.contains("Refer a Friend")
        cy.get(':nth-child(7) > :nth-child(4)').click()
        cy.get('.header-title').should('have.text', "Refer a friend")

    })

    it('help and support profile menu', function () {
        cy.contains("Help & Support")
        cy.get(':nth-child(7) > :nth-child(6)').click()
        cy.get('.header-title').should('have.text', "Help & Support")

    })

    it('terms and coditions profile menu', function () {
        cy.contains("Terms & Conditions")
        cy.get(':nth-child(7) > :nth-child(8)').click()
        cy.get('.header-title').should('have.text', "Terms & Conditions")

    })

    it('rate us profile menu', function () {
        cy.contains("Rate Us")
        cy.get(':nth-child(7) > :nth-child(10)').click()
        cy.get('.header-title').should('have.text', "Rate Us")

    })

    it('about us profile menu', function () {
        cy.contains("About Us")
        cy.get(':nth-child(7) > :nth-child(12)').click()
        cy.get('.header-title').should('have.text', "About Us")
        cy.contains("Introduction")
        cy.contains("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec elementum massa a orci eleifend porttitor sed in diam. Integer efficitur blandit tincidunt. Sed eu auctor felis. Cras vel odio non purus pretium fermentum in et metus. Nullam in tellus placerat, aliquam mauris non, rhoncus est. Suspendisse vitae dapibus ipsum, quis convallis urna. Sed tempus, velit ut hendrerit faucibus, tellus tellus vestibulum metus, in porta nunc nisi lacinia sapien. Pellentesque vel dignissim sapien. Aenean et tristique neque. Quisque eget elementum ante. Curabitur rutrum eleifend libero ac scelerisque. Quisque cursus ac neque vitae aliquet. Donec turpis ante, imperdiet ut purus sit amet, porttitor fringilla ante. Donec congue, nisl ac aliquam tempus, dolor elit tristique diam, quis accumsan quam odio imperdiet justo. Integer eros erat, consectetur quis porta eget, mattis vel lacus. Quisque et gravida lacus. Proin sollicitudin vehicula dictum. Curabitur feugiat malesuada purus in sollicitudin. Sed placerat scelerisque lorem nec vehicula. Donec orci ante, dignissim lobortis dui non, gravida porttitor erat. Aliquam nec ante ex. Etiam eu bibendum enim.")
    })


})