import "../customer/commands";
//import "./merchant.login.spec";

describe("Merchant-MyJobPage", function () {

    beforeEach(function () {
        cy.restoreLocalStorageCache();
        cy.merchantloign();
    });


    afterEach(function() {
        cy.saveLocalStorageCache();
    });

    it('Navigates to MY Jobs page', function () {

        cy.contains('MY JOBS').should('be.visible').click({force: true});
        cy.wait(10000);
        //check filter dates
        cy.get('#btn-234').should('be.visible');
        cy.get('#btn-759').should('be.visible');
        cy.get('#btn-444').should('be.visible');
        //New jobs
        cy.xpath('//*[@id="scrollingContent"]/div/ui-card[1]/div/div/div[1]').should('be.visible').click({force: true});
        cy.wait(4000);
        //cy.contains('User name').should('be.visible');
        //cy.contains('Location').should('be.visible');
        cy.contains('Job description').should('be.visible');
        //cy.contains('Job status').should('be.visible');
        cy.get('#btn-452').should('be.visible');
        cy.get('#btn-539').should('be.visible');


    });

    it('Navigates to MY Jobs page and Check Active Jobs', function () {

            cy.contains('MY JOBS').should('be.visible').click({force: true});
            cy.wait(10000);
            //check filter dates
            cy.get('#btn-234').should('be.visible');
            cy.get('#btn-759').should('be.visible');
            cy.get('#btn-444').should('be.visible');
            cy.wait(2000);
            //Active jobs
            cy.get('#btn-444').should('be.visible').click();
            cy.contains('Active Job').should('be.visible');


        });

    it('Navigates to MY Jobs and Ignore a job', function () {

            cy.contains('MY JOBS').should('be.visible').click({force: true});
            cy.wait(10000);
            //check filter dates
            cy.get('#btn-234').should('be.visible');
            cy.get('#btn-759').should('be.visible');
            cy.get('#btn-444').should('be.visible');
            //New jobs
            cy.xpath('//*[@id="scrollingContent"]/div/ui-card[1]/div/div/div[1]').should('be.visible').click({force: true});

            cy.wait(1000);
            cy.get('#btn-452').should('be.visible').click({force: true});
            cy.wait(10000);
            cy.contains('Beyond my scope of work').should('be.visible').click();
            cy.contains('Destination too far').should('be.visible').click();
            cy.contains('Unavailable on the requested date').should('be.visible').click();
            cy.contains('Other').should('be.visible').click();

            cy.get('textarea').type('Testing123');
            cy.wait(2000);
            cy.get('#btn-468').should('be.visible').click();
            cy.contains('Thanks for the feedback!').should('be.visible');

        });


        it('Navigates to MY Jobs and Accept a job', function () {

            cy.contains('MY JOBS').should('be.visible').click({force: true});
            cy.wait(10000);
            //check filter dates
            cy.get('#btn-234').should('be.visible');
            cy.get('#btn-759').should('be.visible');
            cy.get('#btn-444').should('be.visible');
            //New jobs
            cy.xpath('//*[@id="scrollingContent"]/div/ui-card[1]/div/div/div[1]').should('be.visible').click({force: true});

            cy.wait(1000);
            cy.get('#btn-539').should('be.visible').click();
            cy.wait(2000);

            cy.get('#txtf-556').type('Testing123');
            cy.get('#btn-1090').should('be.visible').click();
            cy.wait(2000);
            cy.contains('Your response has been sent!').should('be.visible');
            cy.get('#btn-294').should('be.visible').click();

        });



    });
