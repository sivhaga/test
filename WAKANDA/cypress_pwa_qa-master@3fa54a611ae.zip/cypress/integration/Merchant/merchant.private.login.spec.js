import "../customer/commands";
var current_view_port;
var baseUrl = Cypress.env("merchantBaseUrl");
var device_sizes = Cypress.env("deviceSizes");

afterEach(function() {
    cy.saveLocalStorageCache();
});

describe("Avo User Private Login", function () {
    it("Does Private Login", function () {
        cy.visit(Cypress.env("merchantBaseUrl"));
        cy.wait(2000);
        cy.get('input[name=username]').type(Cypress.env('privateLoginUsername'));
        cy.on('fail', (err) => {  //If the above fails dont fail the test
          //debugger
        })
        cy.get('input[name=password]').type(Cypress.env('privateLoginPassword'));
        cy.get('#btn-377').click();

        cy.contains('button', 'Let\'s get started').click();
    });
});
