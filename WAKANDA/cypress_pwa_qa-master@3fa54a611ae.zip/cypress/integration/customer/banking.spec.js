//import "./login.spec"
import "./commands"
describe("Banking Services", function () {

    beforeEach(function () {
        cy.customerloign();
        cy.restoreLocalStorageCache();

    });

    afterEach(function() {
        cy.saveLocalStorageCache();
    });

//    it('Navigate to Personal Loans screen', function () {
//        cy.wait(5000);
//        cy.contains('Categories').should('be.visible').click({force: true});
//        cy.wait(3000);
//        cy.contains('Banking').click({force: true});
//        cy.wait(3000);
//        cy.contains('Personal Loans').should('be.visible').click({force: true});
//        cy.wait(2000);
//    });

     it('Navigate to HomeLoans Property report ', function () {
            // cy.visit('/dashboard/v1/customer/board');
            cy.wait(5000);
            cy.contains('Categories').should('be.visible').click({force: true});
            cy.wait(3000);
            cy.contains('Banking').click({force: true});
            cy.contains('Home Buying Toolkit').should('be.visible').click({force: true});
            cy.contains('Property report').should('be.visible').click({force: true});
            cy.wait(10000);
            cy.contains('Get useful insights about your dream home').should('be.visible');
            cy.contains('Get a maximum of 3 free reports per month.').should('be.visible');
            cy.contains('Find out what your dream home is really worth based on the valuation.').should('be.visible');
            cy.wait(2000);
            cy.get('#btn-319').click({force: true});
            cy.wait(5000);
             cy.get('#txtf-2217').click();
            cy.get('#txtf-2217').type('3077 Bryanston Ext 5, Randburg, 2194 {enter}');
            cy.wait(15000);
            cy.contains('3077 Bryanston Ext 5, Randburg, 2194').click({force: true});
            cy.contains('I accept the').click({force: true});

            cy.get('#btn-468').click({force: true});
            cy.wait(10000);
      });

      it('Navigate to Insurance ', function () {
             // cy.visit('/dashboard/v1/customer/board');
              cy.wait(5000);
              cy.contains('Categories').should('be.visible').click({force: true});
              cy.wait(3000);
              cy.contains('Banking').click({force: true});
              cy.contains('Insurance').should('be.visible').click({force: true});
              cy.contains('Insurance').should('be.visible');
              cy.contains('Select a product').should('be.visible');
              cy.contains('Make sure that you and your family are covered for life\'s toughest moments.').should('be.visible').click({force: true});
              cy.get('#btn-1174').click({force: true}); //Lets get started

              cy.wait(3000);
              cy.contains('Build your funeral cover').should('be.visible');
              cy.get('#btn-852').click({force: true}); //Get my quote btn
              cy.wait(15000);

              cy.contains('POLICY DETAILS').should('be.visible');
              cy.contains('Your cover').should('be.visible');
              cy.contains('Discounts').should('be.visible');
              cy.contains('Total Monthly Premium').should('be.visible');
              cy.contains('Confirm').should('be.visible').click({force: true});
              cy.get('#btn-692').should('be.visible');
              cy.get('#btn-592').should('be.visible').click();

              cy.get('#txtf-1366').type('113455678');
              cy.get('#txtf-1740').type('F Tester');
              cy.get('#txtf-1167').click();
              cy.contains('Current').click({force: true});
              cy.get('#txtf-1148').click();
              cy.contains('1').click({force: true});
              cy.wait(3000);
              //cy.get('#btn-319').should('be.visible');

      });

});