//import "./login.spec";
import "./commands"
var searchChar = 'tabl';
describe("/dashboard", function () {

 beforeEach(function () {
        cy.customerloign();
        cy.restoreLocalStorageCache();

    });

    it('Clicks the search field and validates the text Trending', function () {
        cy.get("#txtf-1988").click();
        cy.contains("Trending");
        cy.wait(2000);
        cy.get('.light').its('length').should('be.gte', 0);
    });

    it('Enters a value to search and validates that the text is displayed on the result list', function (){
        cy.get("#txtf-1988").click();
        cy.contains("Trending");
        cy.wait(2000);
        cy.get('.light').its('length').should('be.gte', 0);
        cy.wait(2000);
        cy.get('#txtf-1988').type(searchChar);
        cy.wait(2000);
        
        var resultItems = cy.get('.select-item');
        resultItems.find('p').contains(searchChar);
        resultItems.its('length').should('be.gte', 0);

        cy.get('.select-item').find('p').first().click();
        cy.contains('results in all Product');

        cy.get('.description').its('length').should('be.gte', 0);
    });
});