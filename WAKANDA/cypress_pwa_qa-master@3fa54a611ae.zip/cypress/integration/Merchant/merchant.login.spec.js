import "../customer/commands"
var current_view_port;
var device_sizes = Cypress.env("deviceSizes");
var baseUrl = Cypress.env("merchantBaseUrl");

describe("AvoBusiness User login", function () {

   beforeEach(function () {
       cy.visit(baseUrl);
       cy.wait(2000);
      var returnedUrl = "";
       cy.url().then(url => {
         returnedUrl = url;
         if(returnedUrl == 'https://pwa-merchant-stage.wakago.net/home'){
                cy.contains('MY ACCOUNT').should('be.visible').click({force: true});
                cy.wait(5000);
                cy.contains('LOGOUT').scrollIntoView()
                cy.contains('LOGOUT').should('be.visible').click({force: true});

               returnedUrl = "";
          };
       });
   });

     afterEach(function () {
        cy.saveLocalStorageCache();
    });

    it('Enrolls and Logs in the AvoBusiness User', function () {
    cy.wait(2000);
    cy.wait(2000);
      var returnedUrl = "";
       cy.url().then(url => {
         returnedUrl = url;
         if(returnedUrl == 'https://pwa-merchant-stage.wakago.net/private/login'){
                cy.get('input[name=username]').type(Cypress.env('privateLoginUsername'));
                cy.get('input[name=password]').type(Cypress.env('privateLoginPassword'));
                cy.get('#btn-377').click();
                cy.contains('button', 'Let\'s get started').click();
                returnedUrl = "";
          };
       });

        cy.get('input[name=username]').type(Cypress.env('merchantUsername'));
        cy.wait(1000);
        cy.get('#btn-377').should('be.enabled').click();
        cy.wait(1000);
        cy.get('#txtf-883').type(Cypress.env('merchantPassword'));
        cy.wait(1000);
        cy.contains('button', 'LOGIN').should('be.enabled').click({force: true});
        cy.wait(2000);
        cy.completeOTP();
        /**
         * cy.contains('button', 'LOGIN').should('be.enabled').click()
         * Removed as the screen nnow proceeds on blur of the lasts text fields on OTP
         */

         cy.get('#btn-469').click();

        cy.wait(15000);

    });
});