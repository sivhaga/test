var current_view_port;
var baseUrl = Cypress.env("customerLoginUrl");
var device_sizes = Cypress.env("deviceSizes");

describe("Avo User login", function () {

    beforeEach(function () {
        cy.visit("/");
        cy.wait(2000);

        cy.get('#txtf-520').type('test@nedbank.co.za');
        cy.get('#btn-468').should('be.enabled').click({force: true});
//        cy.get('#btn-1590').should('be.enabled').click({force: true}); //Let\'s get started'
//        cy.get('#btn-409').should('be.enabled').click({force: true}); //LOgin


//        cy.get('input[name=username]').type(Cypress.env('privateLoginUsername'));
//        cy.get('input[name=password]').type(Cypress.env('privateLoginPassword'));
//        cy.contains('button', 'CONTINUE').click();
//        cy.contains('button', 'Let\'s get started').click();
        cy.viewport(current_view_port);
    });


    console.log(device_sizes);
    device_sizes.forEach(function(size) {

        if (Cypress._.isArray(size)) {
            var width = size[0];
            var height = size[1];
            current_view_port = [width, height];
        }
        else {
            current_view_port = size;
        }

        it('User Login', function () {
//            cy.pause();
            cy.get('#btn-409').click();
            cy.get('input[name=username]').type(Cypress.env('customerUsername'));
            cy.get('button').should('be.enabled').click();
            cy.get('input[name=password]').type(Cypress.env('customerPassword'));
            cy.get('button').should('be.enabled').click();
            cy.wait(1000);
            var i = 1;
            cy.get('.digits').each(function($digits, i) {
                i = i + 1;
                cy.wrap($digits).find('input').type(i);
            });
            cy.get('button').should('be.enabled').click();
        });
    });
});
